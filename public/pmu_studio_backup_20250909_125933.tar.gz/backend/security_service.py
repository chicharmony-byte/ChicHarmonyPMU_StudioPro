from typing import Dict, List, Optional, Any, Tuple
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
import os
import secrets
import hashlib
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import ipaddress
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class SecurityService:
    def __init__(self, db):
        self.db = db
        
        # Configuración de seguridad
        self.max_login_attempts = 5
        self.lockout_duration = timedelta(minutes=30)
        self.session_timeout = timedelta(hours=24)
        self.password_history_count = 5
        
        # Configuración de encriptación
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher_suite = Fernet(self.encryption_key)
        
        # Lista de campos sensibles que requieren encriptación
        self.sensitive_fields = {
            "clients": ["phone", "email", "address", "medical_notes", "emergency_contact"],
            "appointments": ["client_notes", "medical_conditions", "allergies"],
            "forms": ["signature_data", "medical_information", "personal_data"],
            "payments": ["card_last_four", "transaction_details"]
        }
        
        # Configuración de auditoría
        self.audit_events = {
            "login": "User Login",
            "logout": "User Logout", 
            "failed_login": "Failed Login Attempt",
            "password_change": "Password Changed",
            "data_access": "Sensitive Data Accessed",
            "data_modify": "Sensitive Data Modified",
            "account_locked": "Account Locked",
            "permission_denied": "Permission Denied",
            "export_data": "Data Export",
            "delete_data": "Data Deletion"
        }

    def _get_or_create_encryption_key(self) -> bytes:
        """Obtener o crear clave de encriptación"""
        try:
            key_file = Path("/app/backend/.encryption_key")
            
            if key_file.exists():
                with open(key_file, 'rb') as f:
                    return f.read()
            else:
                # Generar nueva clave
                key = Fernet.generate_key()
                with open(key_file, 'wb') as f:
                    f.write(key)
                # Establecer permisos restrictivos
                os.chmod(key_file, 0o600)
                return key
                
        except Exception as e:
            logger.error(f"Error managing encryption key: {str(e)}")
            # Fallback: usar clave de entorno o generar temporal
            env_key = os.environ.get('ENCRYPTION_KEY')
            if env_key:
                return base64.urlsafe_b64decode(env_key.encode())
            else:
                return Fernet.generate_key()

    async def encrypt_sensitive_data(self, data: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """Encriptar campos sensibles de un documento"""
        try:
            if collection_name not in self.sensitive_fields:
                return data
            
            encrypted_data = data.copy()
            sensitive_fields = self.sensitive_fields[collection_name]
            
            for field in sensitive_fields:
                if field in encrypted_data and encrypted_data[field]:
                    # Convertir a string si no lo es
                    field_value = str(encrypted_data[field])
                    # Encriptar
                    encrypted_value = self.cipher_suite.encrypt(field_value.encode('utf-8'))
                    encrypted_data[field] = base64.b64encode(encrypted_value).decode('utf-8')
                    
                    # Marcar como encriptado
                    encrypted_data[f"{field}_encrypted"] = True
            
            return encrypted_data
            
        except Exception as e:
            logger.error(f"Error encrypting data: {str(e)}")
            return data

    async def decrypt_sensitive_data(self, data: Dict[str, Any], collection_name: str) -> Dict[str, Any]:
        """Desencriptar campos sensibles de un documento"""
        try:
            if collection_name not in self.sensitive_fields:
                return data
            
            decrypted_data = data.copy()
            sensitive_fields = self.sensitive_fields[collection_name]
            
            for field in sensitive_fields:
                if field in decrypted_data and decrypted_data.get(f"{field}_encrypted"):
                    try:
                        # Desencriptar
                        encrypted_value = base64.b64decode(decrypted_data[field].encode('utf-8'))
                        decrypted_value = self.cipher_suite.decrypt(encrypted_value)
                        decrypted_data[field] = decrypted_value.decode('utf-8')
                        
                        # Remover marca de encriptado
                        decrypted_data.pop(f"{field}_encrypted", None)
                        
                    except Exception as decrypt_error:
                        logger.warning(f"Failed to decrypt field {field}: {str(decrypt_error)}")
                        # Mantener valor encriptado si no se puede desencriptar
            
            return decrypted_data
            
        except Exception as e:
            logger.error(f"Error decrypting data: {str(e)}")
            return data

    async def log_audit_event(self, user_id: str, event_type: str, details: Dict[str, Any], ip_address: str = None, user_agent: str = None):
        """Registrar evento de auditoría"""
        try:
            audit_log = {
                "user_id": user_id,
                "event_type": event_type,
                "event_description": self.audit_events.get(event_type, event_type),
                "details": details,
                "ip_address": ip_address,
                "user_agent": user_agent,
                "timestamp": datetime.utcnow(),
                "session_id": details.get("session_id"),
                "risk_level": self._calculate_risk_level(event_type, details, ip_address)
            }
            
            await self.db.audit_logs.insert_one(audit_log)
            
            # Verificar si hay patrones sospechosos
            await self._check_suspicious_activity(user_id, event_type, ip_address)
            
        except Exception as e:
            logger.error(f"Error logging audit event: {str(e)}")

    async def check_account_lockout(self, user_id: str, ip_address: str = None) -> Dict[str, Any]:
        """Verificar si la cuenta está bloqueada"""
        try:
            # Verificar bloqueo por intentos fallidos
            failed_attempts = await self._get_recent_failed_attempts(user_id, ip_address)
            
            if failed_attempts >= self.max_login_attempts:
                last_attempt = await self.db.audit_logs.find_one(
                    {
                        "user_id": user_id,
                        "event_type": "failed_login",
                        "timestamp": {"$gte": datetime.utcnow() - self.lockout_duration}
                    },
                    sort=[("timestamp", -1)]
                )
                
                if last_attempt:
                    lockout_until = last_attempt["timestamp"] + self.lockout_duration
                    
                    if datetime.utcnow() < lockout_until:
                        return {
                            "locked": True,
                            "reason": "Too many failed login attempts",
                            "lockout_until": lockout_until.isoformat(),
                            "remaining_minutes": int((lockout_until - datetime.utcnow()).total_seconds() / 60)
                        }
            
            # Verificar bloqueo manual
            manual_lockout = await self.db.account_lockouts.find_one(
                {
                    "user_id": user_id,
                    "active": True,
                    "$or": [
                        {"expires_at": {"$gt": datetime.utcnow()}},
                        {"expires_at": None}  # Bloqueo permanente
                    ]
                }
            )
            
            if manual_lockout:
                return {
                    "locked": True,
                    "reason": manual_lockout.get("reason", "Account manually locked"),
                    "lockout_until": manual_lockout.get("expires_at").isoformat() if manual_lockout.get("expires_at") else None,
                    "manual_lockout": True
                }
            
            return {"locked": False}
            
        except Exception as e:
            logger.error(f"Error checking account lockout: {str(e)}")
            return {"locked": False, "error": str(e)}

    async def record_login_attempt(self, user_id: str, success: bool, ip_address: str = None, user_agent: str = None, details: Dict[str, Any] = None):
        """Registrar intento de login"""
        try:
            event_type = "login" if success else "failed_login"
            
            attempt_details = {
                "success": success,
                "ip_address": ip_address,
                "user_agent": user_agent,
                **(details or {})
            }
            
            await self.log_audit_event(user_id, event_type, attempt_details, ip_address, user_agent)
            
            # Si el login fue exitoso, limpiar intentos fallidos previos
            if success:
                await self._clear_failed_attempts(user_id, ip_address)
            
        except Exception as e:
            logger.error(f"Error recording login attempt: {str(e)}")

    async def validate_password_strength(self, password: str, user_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Validar fortaleza de contraseña"""
        try:
            issues = []
            score = 0
            
            # Longitud mínima
            if len(password) < 8:
                issues.append("La contraseña debe tener al menos 8 caracteres")
            else:
                score += 1
            
            # Mayúsculas
            if not any(c.isupper() for c in password):
                issues.append("Debe contener al menos una letra mayúscula")
            else:
                score += 1
            
            # Minúsculas
            if not any(c.islower() for c in password):
                issues.append("Debe contener al menos una letra minúscula")
            else:
                score += 1
            
            # Números
            if not any(c.isdigit() for c in password):
                issues.append("Debe contener al menos un número")
            else:
                score += 1
            
            # Caracteres especiales
            special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
            if not any(c in special_chars for c in password):
                issues.append("Debe contener al menos un carácter especial")
            else:
                score += 1
            
            # Verificar contra datos del usuario
            if user_data:
                user_info = [
                    user_data.get("username", "").lower(),
                    user_data.get("email", "").lower().split("@")[0],
                    user_data.get("first_name", "").lower(),
                    user_data.get("last_name", "").lower()
                ]
                
                for info in user_info:
                    if info and len(info) > 2 and info in password.lower():
                        issues.append("La contraseña no debe contener información personal")
                        score -= 1
                        break
            
            # Verificar contraseñas comunes
            common_passwords = ["password", "123456", "qwerty", "admin", "letmein", "welcome"]
            if password.lower() in common_passwords:
                issues.append("Contraseña demasiado común")
                score -= 2
            
            # Calcular nivel de seguridad
            if score >= 5:
                strength = "Excelente"
                color = "green"
            elif score >= 4:
                strength = "Buena"
                color = "blue"
            elif score >= 3:
                strength = "Regular"
                color = "orange"
            else:
                strength = "Débil"
                color = "red"
            
            return {
                "valid": len(issues) == 0,
                "score": max(0, score),
                "strength": strength,
                "color": color,
                "issues": issues,
                "recommendations": self._get_password_recommendations(issues)
            }
            
        except Exception as e:
            logger.error(f"Error validating password strength: {str(e)}")
            return {
                "valid": False,
                "error": str(e)
            }

    async def check_password_history(self, user_id: str, new_password: str) -> bool:
        """Verificar si la contraseña ya fue usada anteriormente"""
        try:
            # Obtener historial de contraseñas
            password_history = await self.db.password_history.find(
                {"user_id": user_id},
                sort=[("created_at", -1)],
                limit=self.password_history_count
            ).to_list(self.password_history_count)
            
            new_password_hash = hashlib.sha256(new_password.encode()).hexdigest()
            
            for entry in password_history:
                if entry["password_hash"] == new_password_hash:
                    return False  # Contraseña ya usada
            
            return True  # Contraseña nueva
            
        except Exception as e:
            logger.error(f"Error checking password history: {str(e)}")
            return True  # En caso de error, permitir la contraseña

    async def store_password_history(self, user_id: str, password_hash: str):
        """Almacenar contraseña en el historial"""
        try:
            # Agregar nueva entrada
            await self.db.password_history.insert_one({
                "user_id": user_id,
                "password_hash": password_hash,
                "created_at": datetime.utcnow()
            })
            
            # Limpiar entradas antiguas (mantener solo las últimas N)
            total_entries = await self.db.password_history.count_documents({"user_id": user_id})
            
            if total_entries > self.password_history_count:
                oldest_entries = await self.db.password_history.find(
                    {"user_id": user_id},
                    sort=[("created_at", 1)],
                    limit=total_entries - self.password_history_count
                ).to_list(total_entries)
                
                for entry in oldest_entries:
                    await self.db.password_history.delete_one({"_id": entry["_id"]})
            
        except Exception as e:
            logger.error(f"Error storing password history: {str(e)}")

    async def generate_secure_token(self, purpose: str, user_id: str, expires_minutes: int = 60) -> str:
        """Generar token seguro para operaciones específicas"""
        try:
            token = secrets.token_urlsafe(32)
            expires_at = datetime.utcnow() + timedelta(minutes=expires_minutes)
            
            await self.db.secure_tokens.insert_one({
                "token": token,
                "purpose": purpose,
                "user_id": user_id,
                "created_at": datetime.utcnow(),
                "expires_at": expires_at,
                "used": False
            })
            
            return token
            
        except Exception as e:
            logger.error(f"Error generating secure token: {str(e)}")
            return None

    async def validate_secure_token(self, token: str, purpose: str, user_id: str = None) -> Dict[str, Any]:
        """Validar token seguro"""
        try:
            query = {
                "token": token,
                "purpose": purpose,
                "used": False,
                "expires_at": {"$gt": datetime.utcnow()}
            }
            
            if user_id:
                query["user_id"] = user_id
            
            token_doc = await self.db.secure_tokens.find_one(query)
            
            if not token_doc:
                return {"valid": False, "reason": "Token inválido o expirado"}
            
            # Marcar token como usado
            await self.db.secure_tokens.update_one(
                {"_id": token_doc["_id"]},
                {"$set": {"used": True, "used_at": datetime.utcnow()}}
            )
            
            return {
                "valid": True,
                "user_id": token_doc["user_id"],
                "created_at": token_doc["created_at"],
                "purpose": token_doc["purpose"]
            }
            
        except Exception as e:
            logger.error(f"Error validating secure token: {str(e)}")
            return {"valid": False, "reason": str(e)}

    async def get_security_report(self, user_id: str, days: int = 30) -> Dict[str, Any]:
        """Generar reporte de seguridad"""
        try:
            start_date = datetime.utcnow() - timedelta(days=days)
            
            # Obtener logs de auditoría
            audit_logs = await self.db.audit_logs.find({
                "user_id": user_id,
                "timestamp": {"$gte": start_date}
            }).to_list(1000)
            
            # Analizar patrones
            login_attempts = len([log for log in audit_logs if log["event_type"] == "login"])
            failed_logins = len([log for log in audit_logs if log["event_type"] == "failed_login"])
            
            # IPs únicas
            unique_ips = set(log.get("ip_address") for log in audit_logs if log.get("ip_address"))
            
            # Eventos de alto riesgo
            high_risk_events = [log for log in audit_logs if log.get("risk_level") == "high"]
            
            # Actividad por día
            daily_activity = {}
            for log in audit_logs:
                day = log["timestamp"].strftime("%Y-%m-%d")
                daily_activity[day] = daily_activity.get(day, 0) + 1
            
            return {
                "success": True,
                "period": f"Últimos {days} días",
                "summary": {
                    "total_events": len(audit_logs),
                    "successful_logins": login_attempts,
                    "failed_logins": failed_logins,
                    "unique_ips": len(unique_ips),
                    "high_risk_events": len(high_risk_events)
                },
                "security_score": self._calculate_security_score(audit_logs),
                "recommendations": self._generate_security_recommendations(audit_logs),
                "recent_ips": list(unique_ips)[-10:],  # Últimas 10 IPs
                "daily_activity": daily_activity,
                "high_risk_events": [
                    {
                        "event": event["event_type"],
                        "timestamp": event["timestamp"].isoformat(),
                        "details": event.get("details", {})
                    } for event in high_risk_events[-10:]  # Últimos 10
                ]
            }
            
        except Exception as e:
            logger.error(f"Error generating security report: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _get_recent_failed_attempts(self, user_id: str, ip_address: str = None) -> int:
        """Obtener número de intentos fallidos recientes"""
        try:
            query = {
                "user_id": user_id,
                "event_type": "failed_login",
                "timestamp": {"$gte": datetime.utcnow() - self.lockout_duration}
            }
            
            if ip_address:
                query["ip_address"] = ip_address
            
            return await self.db.audit_logs.count_documents(query)
            
        except Exception as e:
            logger.error(f"Error getting recent failed attempts: {str(e)}")
            return 0

    async def _clear_failed_attempts(self, user_id: str, ip_address: str = None):
        """Limpiar intentos fallidos después de login exitoso"""
        try:
            query = {
                "user_id": user_id,
                "event_type": "failed_login",
                "timestamp": {"$gte": datetime.utcnow() - self.lockout_duration}
            }
            
            if ip_address:
                query["ip_address"] = ip_address
            
            # Marcar como limpiados en lugar de eliminar (para auditoría)
            await self.db.audit_logs.update_many(
                query,
                {"$set": {"cleared": True, "cleared_at": datetime.utcnow()}}
            )
            
        except Exception as e:
            logger.error(f"Error clearing failed attempts: {str(e)}")

    def _calculate_risk_level(self, event_type: str, details: Dict[str, Any], ip_address: str = None) -> str:
        """Calcular nivel de riesgo del evento"""
        try:
            high_risk_events = ["failed_login", "permission_denied", "account_locked", "delete_data"]
            medium_risk_events = ["password_change", "data_modify", "export_data"]
            
            if event_type in high_risk_events:
                return "high"
            elif event_type in medium_risk_events:
                return "medium"
            else:
                return "low"
                
        except Exception as e:
            logger.error(f"Error calculating risk level: {str(e)}")
            return "low"

    async def _check_suspicious_activity(self, user_id: str, event_type: str, ip_address: str = None):
        """Verificar actividad sospechosa"""
        try:
            # Verificar múltiples intentos fallidos desde diferentes IPs
            if event_type == "failed_login":
                recent_fails = await self.db.audit_logs.find({
                    "user_id": user_id,
                    "event_type": "failed_login",
                    "timestamp": {"$gte": datetime.utcnow() - timedelta(minutes=10)}
                }).to_list(100)
                
                unique_ips = set(log.get("ip_address") for log in recent_fails if log.get("ip_address"))
                
                if len(unique_ips) > 3:  # Más de 3 IPs diferentes
                    await self.log_audit_event(
                        user_id, 
                        "suspicious_activity", 
                        {
                            "reason": "Multiple failed logins from different IPs",
                            "ip_count": len(unique_ips),
                            "ips": list(unique_ips)
                        }
                    )
            
        except Exception as e:
            logger.error(f"Error checking suspicious activity: {str(e)}")

    def _get_password_recommendations(self, issues: List[str]) -> List[str]:
        """Generar recomendaciones para mejorar la contraseña"""
        recommendations = []
        
        if any("8 caracteres" in issue for issue in issues):
            recommendations.append("Usa al menos 12 caracteres para mayor seguridad")
        
        if any("mayúscula" in issue for issue in issues):
            recommendations.append("Incluye letras mayúsculas (A-Z)")
        
        if any("minúscula" in issue for issue in issues):
            recommendations.append("Incluye letras minúsculas (a-z)")
        
        if any("número" in issue for issue in issues):
            recommendations.append("Incluye números (0-9)")
        
        if any("especial" in issue for issue in issues):
            recommendations.append("Incluye símbolos (!@#$%^&*)")
        
        if any("personal" in issue for issue in issues):
            recommendations.append("Evita usar tu nombre, email o información personal")
        
        if any("común" in issue for issue in issues):
            recommendations.append("Evita contraseñas comunes o predecibles")
        
        # Recomendaciones generales
        recommendations.extend([
            "Considera usar una frase de contraseña",
            "Usa un gestor de contraseñas",
            "Cambia la contraseña regularmente"
        ])
        
        return recommendations

    def _calculate_security_score(self, audit_logs: List[Dict]) -> int:
        """Calcular puntuación de seguridad"""
        try:
            score = 100
            
            failed_logins = len([log for log in audit_logs if log["event_type"] == "failed_login"])
            high_risk_events = len([log for log in audit_logs if log.get("risk_level") == "high"])
            
            # Penalizar eventos de riesgo
            score -= min(failed_logins * 2, 30)  # Máximo -30 por logins fallidos
            score -= min(high_risk_events * 5, 40)  # Máximo -40 por eventos de alto riesgo
            
            return max(0, score)
            
        except Exception as e:
            logger.error(f"Error calculating security score: {str(e)}")
            return 50

    def _generate_security_recommendations(self, audit_logs: List[Dict]) -> List[str]:
        """Generar recomendaciones de seguridad"""
        recommendations = []
        
        failed_logins = len([log for log in audit_logs if log["event_type"] == "failed_login"])
        
        if failed_logins > 10:
            recommendations.append("Considera habilitar autenticación de dos factores")
        
        if failed_logins > 5:
            recommendations.append("Revisa y fortalece tu contraseña")
        
        unique_ips = set(log.get("ip_address") for log in audit_logs if log.get("ip_address"))
        if len(unique_ips) > 10:
            recommendations.append("Accesos desde muchas IPs diferentes - verifica la seguridad")
        
        recommendations.extend([
            "Mantén actualizada tu información de seguridad",
            "Revisa regularmente los logs de actividad",
            "Usa conexiones seguras (HTTPS)"
        ])
        
        return recommendations

# Esta función se inicializará cuando se importe el módulo
def create_security_service(db):
    return SecurityService(db)