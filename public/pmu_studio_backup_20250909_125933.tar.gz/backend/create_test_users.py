#!/usr/bin/env python3
"""
Script to create test users for PMU Studio app
"""
import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from auth_utils import hash_password
from models import User, UserRole
from dotenv import load_dotenv
import stripe
from datetime import datetime

load_dotenv()

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'backend')]

# Stripe configuration
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

async def create_test_users():
    """Create test users for different subscription levels"""
    print("🔧 Creating test users...")
    
    test_users = [
        {
            'email': 'standard@test.com',
            'username': 'StandardUser',
            'password': 'pass123',
            'role': UserRole.STANDARD
        },
        {
            'email': 'premium@test.com',
            'username': 'PremiumUser',
            'password': 'pass123',
            'role': UserRole.PREMIUM
        },
        {
            'email': 'executive@test.com',
            'username': 'ExecutiveUser',
            'password': 'pass123',
            'role': UserRole.EXECUTIVE
        }
    ]
    
    created_count = 0
    
    for user_data in test_users:
        try:
            # Check if user already exists
            existing_user = await db.users.find_one({"email": user_data['email']})
            if existing_user:
                print(f"⚠️  User {user_data['email']} already exists, skipping...")
                continue
            
            # Create Stripe customer
            try:
                stripe_customer = stripe.Customer.create(
                    email=user_data['email'],
                    name=user_data['username']
                )
                print(f"✅ Created Stripe customer for {user_data['email']}")
            except Exception as e:
                print(f"⚠️  Failed to create Stripe customer for {user_data['email']}: {str(e)}")
                stripe_customer = None
            
            # Hash password
            hashed_password = hash_password(user_data['password'])
            
            # Create user
            new_user = User(
                email=user_data['email'],
                username=user_data['username'],
                hashed_password=hashed_password,
                role=user_data['role'],
                stripe_customer_id=stripe_customer.id if stripe_customer else None,
                is_active=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            result = await db.users.insert_one(new_user.dict())
            
            if result.inserted_id:
                print(f"✅ Created user: {user_data['email']} ({user_data['role']})")
                created_count += 1
            else:
                print(f"❌ Failed to create user: {user_data['email']}")
                
        except Exception as e:
            print(f"❌ Error creating user {user_data['email']}: {str(e)}")
    
    print(f"\n🎉 Created {created_count} test users successfully!")
    
    # List all users
    print("\n📋 Current users in database:")
    users = await db.users.find({}).to_list(100)
    for user in users:
        print(f"  - {user['email']} ({user['role']}) - Active: {user['is_active']}")

async def main():
    try:
        await create_test_users()
    except Exception as e:
        print(f"❌ Error: {str(e)}")
    finally:
        client.close()

if __name__ == "__main__":
    asyncio.run(main())