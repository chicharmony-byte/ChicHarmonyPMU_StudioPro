from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File, Depends, Body, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import HTMLResponse, RedirectResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from typing import List, Optional
import uuid
from datetime import datetime, timedelta
import base64
from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent
import stripe
import hashlib

# Import our new modules
from models import *
from auth_utils import *
from email_service import email_service
from ai_service import ai_service
from forms_service import forms_service
from analytics_service import create_analytics_service
from calendar_service import create_calendar_service

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'backend')]

# Initialize analytics service
analytics_service = create_analytics_service(db)

# Initialize calendar service
calendar_service = create_calendar_service(db)

# Emergent LLM key
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

# Stripe configuration
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')
STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY')

# Subscription pricing (in cents)
SUBSCRIPTION_PRICES = {
    SubscriptionPlan.STANDARD_MONTHLY: 3500,  # $35.00
    SubscriptionPlan.STANDARD_ANNUAL: 35000,  # $350.00
    SubscriptionPlan.PREMIUM_MONTHLY: 6500,   # $65.00
    SubscriptionPlan.PREMIUM_ANNUAL: 65000,   # $650.00
    SubscriptionPlan.EXECUTIVE_MONTHLY: 12000, # $120.00
    SubscriptionPlan.EXECUTIVE_ANNUAL: 120000  # $1,200.00
}

# Create the main app without a prefix
app = FastAPI(title="Chic Harmony - PMU Studio Management System")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# =============================================================================
# AUTHENTICATION ROUTES
# =============================================================================

@api_router.post("/auth/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register_user(user_data: UserRegistration):
    """Register new user account with role assignment."""
    try:
        # Validate password confirmation
        if user_data.password != user_data.confirm_password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Password confirmation does not match"
            )
        
        # Check existing user
        existing_user = await db.users.find_one({"email": user_data.email.lower()})
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email already registered"
            )
        
        # Check username uniqueness
        existing_username = await db.users.find_one({"username": user_data.username})
        if existing_username:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Username already exists"
            )
        
        # Create Stripe customer
        try:
            stripe_customer = stripe.Customer.create(
                email=user_data.email.lower(),
                name=user_data.username
            )
        except Exception as e:
            logging.error(f"Failed to create Stripe customer: {str(e)}")
            stripe_customer = None
        
        # Create user account
        hashed_password = hash_password(user_data.password)
        new_user = User(
            email=user_data.email.lower(),
            username=user_data.username,
            hashed_password=hashed_password,
            role=user_data.role,
            stripe_customer_id=stripe_customer.id if stripe_customer else None,
            is_active=True
        )
        
        result = await db.users.insert_one(new_user.dict())
        
        if result.inserted_id:
            # Send welcome email
            try:
                plan_mapping = {
                    UserRole.STANDARD: "standard",
                    UserRole.PREMIUM: "premium", 
                    UserRole.EXECUTIVE: "executive"
                }
                plan_name = plan_mapping.get(new_user.role, "standard")
                email_service.send_welcome_email(new_user.email, new_user.username, plan_name)
            except Exception as e:
                logging.warning(f"Failed to send welcome email: {str(e)}")
            
            return UserResponse(**new_user.dict())
        else:
            raise HTTPException(status_code=500, detail="Failed to create user")
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error creating user: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/auth/login")
async def login_user(request: Request, form_data: OAuth2PasswordRequestForm = Depends()):
    """Authenticate user and return access tokens or redirect to dashboard."""
    try:
        # Find user by email
        user = await db.users.find_one({"email": form_data.username.lower()})
        if not user or not verify_password(form_data.password, user["hashed_password"]):
            # Return HTML error page for server-side form
            error_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Error de Login - PMU Studio</title>
                <style>
                    body {{ 
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto; 
                        background: #0F0F0F; 
                        color: #FFFFFF; 
                        display: flex; 
                        justify-content: center; 
                        align-items: center; 
                        min-height: 100vh; 
                        margin: 0; 
                    }}
                    .error-container {{ 
                        text-align: center; 
                        padding: 40px; 
                        background: #1F1F1F; 
                        border-radius: 16px; 
                        border: 1px solid #374151; 
                    }}
                    .error-title {{ 
                        font-size: 24px; 
                        color: #EF4444; 
                        margin-bottom: 16px; 
                    }}
                    .error-message {{ 
                        font-size: 16px; 
                        color: #9CA3AF; 
                        margin-bottom: 24px; 
                    }}
                    .back-button {{ 
                        background: #E879F9; 
                        color: #FFFFFF; 
                        border: none; 
                        padding: 12px 24px; 
                        border-radius: 8px; 
                        cursor: pointer; 
                        font-size: 16px; 
                        text-decoration: none; 
                        display: inline-block; 
                    }}
                </style>
                <script>
                    setTimeout(() => {{ window.location.href = '/'; }}, 3000);
                </script>
            </head>
            <body>
                <div class="error-container">
                    <div class="error-title">❌ Error de Autenticación</div>
                    <div class="error-message">Credenciales inválidas. Redirigiendo...</div>
                    <a href="/" class="back-button">Volver al Login</a>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(content=error_html, status_code=401)
        
        if not user.get("is_active"):
            error_html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Cuenta Desactivada - PMU Studio</title>
                <style>
                    body {{ 
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto; 
                        background: #0F0F0F; 
                        color: #FFFFFF; 
                        display: flex; 
                        justify-content: center; 
                        align-items: center; 
                        min-height: 100vh; 
                        margin: 0; 
                    }}
                    .error-container {{ 
                        text-align: center; 
                        padding: 40px; 
                        background: #1F1F1F; 
                        border-radius: 16px; 
                        border: 1px solid #374151; 
                    }}
                </style>
                <script>
                    setTimeout(() => {{ window.location.href = '/'; }}, 3000);
                </script>
            </head>
            <body>
                <div class="error-container">
                    <div style="font-size: 24px; color: #EF4444; margin-bottom: 16px;">⚠️ Cuenta Desactivada</div>
                    <div style="font-size: 16px; color: #9CA3AF; margin-bottom: 24px;">Tu cuenta está desactivada. Contacta al administrador.</div>
                    <a href="/" style="background: #E879F9; color: #FFFFFF; border: none; padding: 12px 24px; border-radius: 8px; text-decoration: none;">Volver</a>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(content=error_html, status_code=401)
        
        # Generate tokens (for future API use)
        token_data = {
            "sub": str(user["id"]),
            "email": user["email"],
            "role": user["role"],
            "subscription_plan": user.get("subscription_plan"),
            "subscription_status": user.get("subscription_status")
        }
        access_token = create_access_token(token_data)
        
        # For server-side form submission, redirect to dashboard with role
        dashboard_url = f"https://chic-harmony-pmu.preview.emergentagent.com/dashboard?role={user['role']}&username={user['username']}"
        return RedirectResponse(url=dashboard_url, status_code=302)
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error during login: {str(e)}")
        error_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Error del Servidor - PMU Studio</title>
            <style>
                body {{ 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto; 
                    background: #0F0F0F; 
                    color: #FFFFFF; 
                    display: flex; 
                    justify-content: center; 
                    align-items: center; 
                    min-height: 100vh; 
                    margin: 0; 
                }}
                .error-container {{ 
                    text-align: center; 
                    padding: 40px; 
                    background: #1F1F1F; 
                    border-radius: 16px; 
                }}
            </style>
            <script>
                setTimeout(() => {{ window.location.href = '/'; }}, 3000);
            </script>
        </head>
        <body>
            <div class="error-container">
                <div style="font-size: 24px; color: #EF4444; margin-bottom: 16px;">🔧 Error del Servidor</div>
                <div style="font-size: 16px; color: #9CA3AF;">Error interno. Redirigiendo...</div>
            </div>
        </body>
        </html>
        """
        return HTMLResponse(content=error_html, status_code=500)

@api_router.post("/auth/login-api", response_model=TokenResponse)
async def login_user_api(form_data: OAuth2PasswordRequestForm = Depends()):
    """API login endpoint that returns JSON tokens for testing and API clients."""
    try:
        # Find user by email
        user = await db.users.find_one({"email": form_data.username.lower()})
        if not user or not verify_password(form_data.password, user["hashed_password"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )
        
        if not user.get("is_active"):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account is disabled"
            )
        
        # Generate tokens
        token_data = {
            "sub": str(user["id"]),
            "email": user["email"],
            "role": user["role"],
            "subscription_plan": user.get("subscription_plan"),
            "subscription_status": user.get("subscription_status")
        }
        access_token = create_access_token(token_data)
        refresh_token = create_refresh_token(token_data)
        
        # Store refresh token in database
        refresh_token_record = RefreshToken(
            user_id=str(user["id"]),
            token_hash=hashlib.sha256(refresh_token.encode()).hexdigest(),
            expires_at=datetime.utcnow() + timedelta(minutes=JWT_REFRESH_TOKEN_EXPIRE_MINUTES)
        )
        await db.refresh_tokens.insert_one(refresh_token_record.dict())
        
        user_response = UserResponse(**user)
        
        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            user=user_response
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error during API login: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/auth/refresh", response_model=TokenResponse)
async def refresh_tokens(refresh_data: RefreshTokenRequest):
    """Generate new access token using refresh token."""
    try:
        # Validate refresh token
        payload = verify_token(refresh_data.refresh_token, "refresh")
        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid refresh token"
            )
        
        # Check token in database
        token_hash = hashlib.sha256(refresh_data.refresh_token.encode()).hexdigest()
        stored_token = await db.refresh_tokens.find_one({
            "user_id": payload["sub"],
            "token_hash": token_hash,
            "is_revoked": False,
            "expires_at": {"$gt": datetime.utcnow()}
        })
        
        if not stored_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has been revoked or expired"
            )
        
        # Get user
        user = await db.users.find_one({"id": payload["sub"]})
        if not user or not user.get("is_active"):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account is disabled"
            )
        
        # Generate new token pair
        token_data = {
            "sub": str(user["id"]),
            "email": user["email"],
            "role": user["role"],
            "subscription_plan": user.get("subscription_plan"),
            "subscription_status": user.get("subscription_status")
        }
        new_access_token = create_access_token(token_data)
        new_refresh_token = create_refresh_token(token_data)
        
        # Revoke old refresh token
        await db.refresh_tokens.update_one(
            {"id": stored_token["id"]},
            {"$set": {"is_revoked": True}}
        )
        
        # Store new refresh token
        new_refresh_token_record = RefreshToken(
            user_id=str(user["id"]),
            token_hash=hashlib.sha256(new_refresh_token.encode()).hexdigest(),
            expires_at=datetime.utcnow() + timedelta(minutes=JWT_REFRESH_TOKEN_EXPIRE_MINUTES)
        )
        await db.refresh_tokens.insert_one(new_refresh_token_record.dict())
        
        user_response = UserResponse(**user)
        
        return TokenResponse(
            access_token=new_access_token,
            refresh_token=new_refresh_token,
            expires_in=JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            user=user_response
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error refreshing tokens: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/auth/logout")
async def logout_user(current_user: dict = Depends(get_current_user_from_token)):
    """Logout user and revoke all refresh tokens."""
    try:
        # Revoke all refresh tokens for this user
        await db.refresh_tokens.update_many(
            {"user_id": current_user["id"]},
            {"$set": {"is_revoked": True}}
        )
        
        return {"message": "Successfully logged out"}
        
    except Exception as e:
        logging.error(f"Error during logout: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/auth/profile", response_model=UserResponse)
async def get_user_profile(current_user: dict = Depends(get_current_user_from_token)):
    """Get current user profile information."""
    try:
        user = await db.users.find_one({"id": current_user["id"]})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return UserResponse(**user)
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error fetching profile: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# SUBSCRIPTION AND PAYMENT ROUTES
# =============================================================================
# =============================================================================

@api_router.get("/subscriptions/config")
async def get_subscription_config():
    """Get subscription configuration and pricing."""
    return {
        "publishable_key": STRIPE_PUBLISHABLE_KEY,
        "plans": {
            "standard": {
                "monthly": {"price": SUBSCRIPTION_PRICES[SubscriptionPlan.STANDARD_MONTHLY], "name": "Standard Monthly"},
                "annual": {"price": SUBSCRIPTION_PRICES[SubscriptionPlan.STANDARD_ANNUAL], "name": "Standard Annual"}
            },
            "premium": {
                "monthly": {"price": SUBSCRIPTION_PRICES[SubscriptionPlan.PREMIUM_MONTHLY], "name": "Premium Monthly"},
                "annual": {"price": SUBSCRIPTION_PRICES[SubscriptionPlan.PREMIUM_ANNUAL], "name": "Premium Annual"}
            },
            "executive": {
                "monthly": {"price": SUBSCRIPTION_PRICES[SubscriptionPlan.EXECUTIVE_MONTHLY], "name": "Executive Monthly"},
                "annual": {"price": SUBSCRIPTION_PRICES[SubscriptionPlan.EXECUTIVE_ANNUAL], "name": "Executive Annual"}
            }
        }
    }

@api_router.post("/subscriptions/create-payment-intent")
async def create_payment_intent(
    subscription_data: SubscriptionCreate,
    current_user: dict = Depends(get_current_user_from_token)
):
    """Create a payment intent for subscription."""
    try:
        # Get user from database
        user = await db.users.find_one({"id": current_user["id"]})
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Get price for the selected plan
        price = SUBSCRIPTION_PRICES.get(subscription_data.plan)
        if not price:
            raise HTTPException(status_code=400, detail="Invalid subscription plan")
        
        # Create payment intent
        intent = stripe.PaymentIntent.create(
            amount=price,
            currency='usd',
            customer=user.get("stripe_customer_id"),
            payment_method=subscription_data.payment_method_id,
            confirmation_method='manual',
            confirm=True,
            metadata={
                'user_id': user["id"],
                'subscription_plan': subscription_data.plan
            }
        )
        
        if intent.status == 'succeeded':
            # Update user subscription
            role_mapping = {
                SubscriptionPlan.STANDARD_MONTHLY: UserRole.STANDARD,
                SubscriptionPlan.STANDARD_ANNUAL: UserRole.STANDARD,
                SubscriptionPlan.PREMIUM_MONTHLY: UserRole.PREMIUM,
                SubscriptionPlan.PREMIUM_ANNUAL: UserRole.PREMIUM,
                SubscriptionPlan.EXECUTIVE_MONTHLY: UserRole.EXECUTIVE,
                SubscriptionPlan.EXECUTIVE_ANNUAL: UserRole.EXECUTIVE,
            }
            
            await db.users.update_one(
                {"id": user["id"]},
                {"$set": {
                    "subscription_plan": subscription_data.plan,
                    "subscription_status": SubscriptionStatus.ACTIVE,
                    "role": role_mapping[subscription_data.plan],
                    "updated_at": datetime.utcnow()
                }}
            )
            
            return {
                "success": True,
                "payment_intent": {
                    "id": intent.id,
                    "status": intent.status
                }
            }
        else:
            return {
                "success": False,
                "payment_intent": {
                    "id": intent.id,
                    "status": intent.status,
                    "client_secret": intent.client_secret
                }
            }
            
    except stripe.error.CardError as e:
        raise HTTPException(status_code=400, detail=f"Payment failed: {e.user_message}")
    except Exception as e:
        logging.error(f"Error creating payment intent: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# ROLE-PROTECTED ROUTES - CLIENT MANAGEMENT
# =============================================================================

async def get_current_active_user(current_user: dict = Depends(get_current_user_from_token)):
    """Get current active user for protected routes."""
    user = await db.users.find_one({"id": current_user["id"]})
    if not user or not user.get("is_active"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is disabled"
        )
    return current_user

# =============================================================================
# EMAIL SERVICE ROUTES
# =============================================================================

@api_router.post("/email/send-welcome")
async def send_welcome_email_endpoint(
    user_email: str = Body(...),
    username: str = Body(...),
    plan: str = Body(...)
):
    """Send welcome email to new user (internal use)."""
    try:
        success = email_service.send_welcome_email(user_email, username, plan)
        return {"success": success, "message": "Welcome email sent" if success else "Failed to send email"}
    except Exception as e:
        logging.error(f"Error sending welcome email: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/email/send-appointment-confirmation")
async def send_appointment_confirmation_endpoint(
    appointment_data: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Send appointment confirmation email."""
    try:
        # Extract appointment data
        client_email = appointment_data.get("client_email")
        client_name = appointment_data.get("client_name")
        appointment_date_str = appointment_data.get("appointment_date")
        service_type = appointment_data.get("service_type")
        price = appointment_data.get("price")
        notes = appointment_data.get("notes")
        
        if not all([client_email, client_name, appointment_date_str, service_type]):
            raise HTTPException(status_code=400, detail="Missing required appointment data")
        
        # Parse appointment date
        appointment_date = datetime.fromisoformat(appointment_date_str.replace('Z', '+00:00'))
        
        success = email_service.send_appointment_confirmation(
            client_email, client_name, appointment_date, service_type, price, notes
        )
        
        return {"success": success, "message": "Appointment confirmation sent" if success else "Failed to send email"}
    except Exception as e:
        logging.error(f"Error sending appointment confirmation: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/email/send-appointment-reminder")
async def send_appointment_reminder_endpoint(
    reminder_data: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Send appointment reminder email."""
    try:
        # Extract reminder data
        client_email = reminder_data.get("client_email")
        client_name = reminder_data.get("client_name")
        appointment_date_str = reminder_data.get("appointment_date")
        service_type = reminder_data.get("service_type")
        days_before = reminder_data.get("days_before", 1)
        
        if not all([client_email, client_name, appointment_date_str, service_type]):
            raise HTTPException(status_code=400, detail="Missing required reminder data")
        
        # Parse appointment date
        appointment_date = datetime.fromisoformat(appointment_date_str.replace('Z', '+00:00'))
        
        success = email_service.send_appointment_reminder(
            client_email, client_name, appointment_date, service_type, days_before
        )
        
        return {"success": success, "message": "Appointment reminder sent" if success else "Failed to send email"}
    except Exception as e:
        logging.error(f"Error sending appointment reminder: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/email/send-touchup-reminder")
async def send_touchup_reminder_endpoint(
    touchup_data: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Send touch-up reminder email."""
    try:
        # Extract touch-up data
        client_email = touchup_data.get("client_email")
        client_name = touchup_data.get("client_name")
        original_appointment_date_str = touchup_data.get("original_appointment_date")
        service_type = touchup_data.get("service_type")
        
        if not all([client_email, client_name, original_appointment_date_str, service_type]):
            raise HTTPException(status_code=400, detail="Missing required touch-up data")
        
        # Parse appointment date
        original_appointment_date = datetime.fromisoformat(original_appointment_date_str.replace('Z', '+00:00'))
        
        success = email_service.send_touchup_reminder(
            client_email, client_name, original_appointment_date, service_type
        )
        
        return {"success": success, "message": "Touch-up reminder sent" if success else "Failed to send email"}
    except Exception as e:
        logging.error(f"Error sending touch-up reminder: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# DIGITAL FORMS ROUTES
# =============================================================================

@api_router.get("/forms/available")
async def get_available_forms(current_user: dict = Depends(get_current_active_user)):
    """Get available form types and languages."""
    try:
        return forms_service.get_available_forms()
    except Exception as e:
        logging.error(f"Error getting available forms: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/forms/template/{form_type}/{language}")
async def get_form_template(
    form_type: str, 
    language: str,
    current_user: dict = Depends(get_current_active_user)
):
    """Get form template by type and language."""
    try:
        result = forms_service.get_form_template(form_type, language)
        if not result.get("success"):
            raise HTTPException(status_code=404, detail=result.get("error", "Template not found"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error getting form template: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/forms/template/save")
async def save_custom_template(
    template_data: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Save custom form template."""
    try:
        form_type = template_data.get("form_type")
        language = template_data.get("language")
        template = template_data.get("template")
        
        if not all([form_type, language, template]):
            raise HTTPException(status_code=400, detail="Missing required fields: form_type, language, template")
        
        result = forms_service.save_custom_template(
            form_type=form_type,
            language=language, 
            template_data=template,
            user_id=current_user["id"]
        )
        
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error saving custom template: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/forms/generate")
async def generate_form_instance(
    form_data: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Generate form instance with client data."""
    try:
        form_type = form_data.get("form_type")
        language = form_data.get("language", "es")
        client_data = form_data.get("client_data", {})
        
        if not form_type:
            raise HTTPException(status_code=400, detail="form_type is required")
        
        result = forms_service.generate_form_instance(
            form_type=form_type,
            language=language,
            client_data=client_data,
            user_id=current_user["id"]
        )
        
        if not result.get("success"):
            raise HTTPException(status_code=400, detail=result.get("error"))
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error generating form instance: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/forms/preview")
async def preview_form(
    preview_data: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Preview form with sample data."""
    try:
        form_type = preview_data.get("form_type")
        language = preview_data.get("language", "es")
        
        if not form_type:
            raise HTTPException(status_code=400, detail="form_type is required")
        
        # Sample client data for preview
        sample_client_data = {
            "first_name": "María",
            "last_name": "García",
            "email": "maria.garcia@email.com",
            "phone": "+1 (555) 123-4567",
            "age": "28",
            "appointment_date": "15/12/2025",
            "service_type": "Micropigmentación de cejas - Técnica híbrida"
        }
        
        result = forms_service.generate_form_instance(
            form_type=form_type,
            language=language,
            client_data=sample_client_data,
            user_id=current_user["id"]
        )
        
        if result.get("success"):
            result["preview_mode"] = True
            result["sample_data"] = sample_client_data
        
        return result
    except HTTPException:
        raise  
    except Exception as e:
        logging.error(f"Error previewing form: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# ANALYTICS AND REPORTS ROUTES
# =============================================================================

@api_router.get("/analytics/dashboard")
async def get_analytics_dashboard(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    current_user: dict = Depends(get_current_active_user)
):
    """Get analytics dashboard overview."""
    try:
        date_range = None
        if start_date and end_date:
            date_range = {
                "start_date": start_date,
                "end_date": end_date
            }
        
        result = await analytics_service.get_dashboard_overview(current_user["id"], date_range)
        return result
    except Exception as e:
        logging.error(f"Error getting analytics dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/analytics/report/generate")
async def generate_analytics_report(
    report_request: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Generate detailed analytics report."""
    try:
        report_type = report_request.get("report_type", "monthly")
        date_range = report_request.get("date_range", {})
        
        if not date_range.get("start_date") or not date_range.get("end_date"):
            raise HTTPException(status_code=400, detail="start_date and end_date are required")
        
        result = await analytics_service.generate_detailed_report(
            user_id=current_user["id"],
            report_type=report_type,
            date_range=date_range
        )
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error generating analytics report: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/analytics/report/export")
async def export_analytics_report(
    export_request: dict = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Export analytics report to Excel."""
    try:
        report_type = export_request.get("report_type", "monthly")
        date_range = export_request.get("date_range", {})
        export_format = export_request.get("format", "excel")
        
        if not date_range.get("start_date") or not date_range.get("end_date"):
            raise HTTPException(status_code=400, detail="start_date and end_date are required")
        
        # Generate report data
        report_data = await analytics_service.generate_detailed_report(
            user_id=current_user["id"],
            report_type=report_type,
            date_range=date_range
        )
        
        # Export to requested format
        if export_format == "excel":
            excel_base64 = await analytics_service.export_report_to_excel(report_data)
            return {
                "success": True,
                "format": "excel",
                "filename": f"pmu_report_{report_type}_{datetime.utcnow().strftime('%Y%m%d')}.xlsx",
                "data": excel_base64,
                "content_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            }
        else:
            # Return JSON format
            return {
                "success": True,
                "format": "json",
                "filename": f"pmu_report_{report_type}_{datetime.utcnow().strftime('%Y%m%d')}.json",
                "data": report_data,
                "content_type": "application/json"
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error exporting analytics report: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/analytics/kpis")
async def get_business_kpis(
    period: str = "month",
    current_user: dict = Depends(get_current_active_user)
):
    """Get key business KPIs for specified period."""
    try:
        # Calculate date range based on period
        end_date = datetime.utcnow()
        if period == "week":
            start_date = end_date - timedelta(days=7)
        elif period == "month":
            start_date = end_date - timedelta(days=30)
        elif period == "quarter":
            start_date = end_date - timedelta(days=90)
        elif period == "year":
            start_date = end_date - timedelta(days=365)
        else:
            start_date = end_date - timedelta(days=30)  # Default to month
        
        date_range = {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
        
        dashboard_data = await analytics_service.get_dashboard_overview(current_user["id"], date_range)
        
        if dashboard_data.get("success"):
            return {
                "success": True,
                "period": period,
                "kpis": dashboard_data.get("kpis", {}),
                "summary": {
                    "total_revenue": dashboard_data.get("financial", {}).get("total_revenue", 0),
                    "total_clients": dashboard_data.get("clients", {}).get("total_clients", 0),
                    "total_appointments": dashboard_data.get("appointments", {}).get("total_appointments", 0),
                    "completion_rate": dashboard_data.get("appointments", {}).get("completion_rate", 0)
                }
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to calculate KPIs")
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error getting business KPIs: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/analytics/trends")
async def get_business_trends(
    metric: str = "revenue",
    period: str = "month",
    current_user: dict = Depends(get_current_active_user)
):
    """Get business trends for specific metrics."""
    try:
        # This would typically analyze historical data trends
        # For now, return a simplified response
        
        end_date = datetime.utcnow()
        if period == "month":
            start_date = end_date - timedelta(days=90)  # 3 months for trends
        elif period == "quarter":
            start_date = end_date - timedelta(days=365)  # 1 year for quarterly trends
        else:
            start_date = end_date - timedelta(days=90)
        
        date_range = {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
        
        dashboard_data = await analytics_service.get_dashboard_overview(current_user["id"], date_range)
        
        return {
            "success": True,
            "metric": metric,
            "period": period,
            "trend_data": {
                "current_value": dashboard_data.get("financial", {}).get("total_revenue", 0) if metric == "revenue" else 0,
                "growth_rate": dashboard_data.get("financial", {}).get("revenue_growth", 0) if metric == "revenue" else 0,
                "trend_direction": "up" if dashboard_data.get("financial", {}).get("revenue_growth", 0) > 0 else "down"
            }
        }
        
    except Exception as e:
        logging.error(f"Error getting business trends: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# ROLE-PROTECTED ROUTES - CLIENT MANAGEMENT
# =============================================================================

@api_router.post("/clients", response_model=Client)
async def create_client(
    client_data: ClientCreate,
    current_user: dict = Depends(get_current_active_user)
):
    """Create a new client (available to all subscription levels)."""
    try:
        # Check permissions
        check_permission(Permission.WRITE_CLIENTS)(current_user)
        
        client = Client(**client_data.dict(), user_id=current_user["id"])
        result = await db.clients.insert_one(client.dict())
        
        if result.inserted_id:
            return client
        else:
            raise HTTPException(status_code=500, detail="Failed to create client")
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error creating client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/clients", response_model=List[Client])
async def get_clients(current_user: dict = Depends(get_current_active_user)):
    """Get all clients for the current user."""
    try:
        check_permission(Permission.READ_CLIENTS)(current_user)
        
        clients = await db.clients.find({"user_id": current_user["id"]}).to_list(1000)
        return [Client(**client) for client in clients]
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error fetching clients: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# ROLE-PROTECTED ROUTES - FINANCE (PREMIUM+ ONLY)
# =============================================================================

@api_router.post("/finance/transactions", response_model=Transaction)
async def create_transaction(
    transaction_data: TransactionCreate,
    current_user: dict = Depends(get_current_active_user)
):
    """Create a new financial transaction (Premium+ only)."""
    try:
        check_permission(Permission.WRITE_FINANCE)(current_user)
        
        transaction = Transaction(**transaction_data.dict(), user_id=current_user["id"])
        if not transaction.date:
            transaction.date = datetime.utcnow()
        
        result = await db.transactions.insert_one(transaction.dict())
        
        if result.inserted_id:
            return transaction
        else:
            raise HTTPException(status_code=500, detail="Failed to create transaction")
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error creating transaction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/finance/transactions", response_model=List[Transaction])
async def get_transactions(
    current_user: dict = Depends(get_current_active_user),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    type: Optional[TransactionType] = None,
    category: Optional[str] = None,
    limit: Optional[int] = 100
):
    """Get financial transactions (Premium+ only)."""
    try:
        check_permission(Permission.READ_FINANCE)(current_user)
        
        query = {"user_id": current_user["id"]}
        
        if start_date and end_date:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query["date"] = {"$gte": start, "$lte": end}
        
        if type:
            query["type"] = type
            
        if category:
            query["category"] = category
        
        transactions = await db.transactions.find(query).sort("date", -1).to_list(limit)
        return [Transaction(**transaction) for transaction in transactions]
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error fetching transactions: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# ROLE-PROTECTED ROUTES - AI DESIGN (EXECUTIVE ONLY)
# =============================================================================

@api_router.post("/ai-design/complete-analysis")
async def complete_facial_analysis(
    photo_base64: str = Body(...),
    client_info: dict = Body(default={}),
    current_user: dict = Depends(get_current_active_user)
):
    """Análisis facial completo integrado con AI (Executive only)."""
    try:
        check_permission(Permission.WRITE_AI_DESIGN)(current_user)
        
        # Realizar análisis completo
        result = await ai_service.complete_facial_analysis(photo_base64, client_info)
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error in complete AI analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/ai-design/analyze-photo")
async def analyze_photo_ai(
    photo_base64: str = Body(...),
    analysis_type: str = Body(...),
    current_user: dict = Depends(get_current_active_user)
):
    """Análisis específico de foto (Legacy endpoint - mantenido por compatibilidad)."""
    try:
        check_permission(Permission.WRITE_AI_DESIGN)(current_user)
        
        if analysis_type == "complete":
            # Usar el nuevo sistema completo
            result = await ai_service.complete_facial_analysis(photo_base64)
            return result
        elif analysis_type == "symmetry":
            analysis_result = await analyze_facial_symmetry(photo_base64)
        elif analysis_type == "color":
            analysis_result = await analyze_skin_color(photo_base64)
        else:
            raise HTTPException(status_code=400, detail="Invalid analysis type")
        
        return analysis_result
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error analyzing photo: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# HELPER FUNCTIONS (From original server)
# =============================================================================

async def analyze_facial_symmetry(photo_base64: str):
    """Analyze facial symmetry using AI"""
    try:
        if not EMERGENT_LLM_KEY:
            return {
                "error": "AI analysis not configured",
                "symmetry_score": 0,
                "recommendations": ["AI analysis requires configuration"]
            }
        
        chat = LlmChat(api_key=EMERGENT_LLM_KEY)
        
        messages = [
            UserMessage(
                content=[
                    "Analyze this photo for facial symmetry for micropigmentation purposes. Provide a detailed analysis including:",
                    "1. Facial symmetry score (0-100)",
                    "2. Key asymmetries identified",
                    "3. Specific recommendations for eyebrow micropigmentation",
                    "4. Areas that need special attention",
                    "5. Suggested measurements and reference points",
                    ImageContent(base64_data=photo_base64)
                ]
            )
        ]
        
        response = await chat.agenerate(messages)
        analysis_text = response.content
        
        return {
            "analysis_type": "facial_symmetry",
            "ai_response": analysis_text,
            "timestamp": datetime.utcnow().isoformat(),
            "success": True
        }
        
    except Exception as e:
        logging.error(f"Error in facial symmetry analysis: {str(e)}")
        return {
            "error": str(e),
            "analysis_type": "facial_symmetry",
            "success": False
        }

async def analyze_skin_color(photo_base64: str):
    """Analyze skin color and undertones using AI"""
    try:
        if not EMERGENT_LLM_KEY:
            return {
                "error": "AI analysis not configured",
                "color_analysis": "Not available",
                "recommendations": ["AI analysis requires configuration"]
            }
        
        chat = LlmChat(api_key=EMERGENT_LLM_KEY)
        
        messages = [
            UserMessage(
                content=[
                    "Analyze this photo for skin color and undertones for micropigmentation color matching. Provide:",
                    "1. Dominant skin tone classification",
                    "2. Undertone analysis (warm, cool, neutral)",
                    "3. Saturation levels",
                    "4. Recommended pigment colors for eyebrows",
                    "5. Color mixing suggestions with percentages",
                    "6. Technical explanation of color choices",
                    ImageContent(base64_data=photo_base64)
                ]
            )
        ]
        
        response = await chat.agenerate(messages)
        analysis_text = response.content
        
        return {
            "analysis_type": "color_analysis",
            "ai_response": analysis_text,
            "timestamp": datetime.utcnow().isoformat(),
            "success": True
        }
        
    except Exception as e:
        logging.error(f"Error in color analysis: {str(e)}")
        return {
            "error": str(e),
            "analysis_type": "color_analysis",
            "success": False
        }

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)