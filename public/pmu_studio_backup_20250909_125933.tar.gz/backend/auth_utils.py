from fastapi import HTTPException, status, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from enum import Enum
import os
from dotenv import load_dotenv

load_dotenv()

# JWT Configuration
JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY")
JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")
JWT_ACCESS_TOKEN_EXPIRE_MINUTES = int(os.environ.get("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", 30))
JWT_REFRESH_TOKEN_EXPIRE_MINUTES = int(os.environ.get("JWT_REFRESH_TOKEN_EXPIRE_MINUTES", 1440))

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# HTTP Bearer token scheme
security = HTTPBearer()

class UserRole(str, Enum):
    STANDARD = "standard"
    PREMIUM = "premium"
    EXECUTIVE = "executive"

class Permission(str, Enum):
    # Client Management - Available to all roles
    READ_CLIENTS = "read:clients"
    WRITE_CLIENTS = "write:clients"
    
    # Appointments - Available to all roles
    READ_APPOINTMENTS = "read:appointments"
    WRITE_APPOINTMENTS = "write:appointments"
    
    # Notifications - Available to all roles
    READ_NOTIFICATIONS = "read:notifications"
    WRITE_NOTIFICATIONS = "write:notifications"
    
    # Finance - Premium and Executive only
    READ_FINANCE = "read:finance"
    WRITE_FINANCE = "write:finance"
    
    # Inventory - Premium and Executive only
    READ_INVENTORY = "read:inventory"
    WRITE_INVENTORY = "write:inventory"
    
    # AI Design Tools - Executive only
    READ_AI_DESIGN = "read:ai_design"
    WRITE_AI_DESIGN = "write:ai_design"
    
    # Admin - Executive only
    ADMIN_USERS = "admin:users"
    ADMIN_SYSTEM = "admin:system"

# Role permissions mapping
ROLE_PERMISSIONS: Dict[UserRole, list[Permission]] = {
    UserRole.STANDARD: [
        Permission.READ_CLIENTS,
        Permission.WRITE_CLIENTS,
        Permission.READ_APPOINTMENTS,
        Permission.WRITE_APPOINTMENTS,
        Permission.READ_NOTIFICATIONS,
        Permission.WRITE_NOTIFICATIONS
    ],
    UserRole.PREMIUM: [
        # Standard permissions
        Permission.READ_CLIENTS,
        Permission.WRITE_CLIENTS,
        Permission.READ_APPOINTMENTS,
        Permission.WRITE_APPOINTMENTS,
        Permission.READ_NOTIFICATIONS,
        Permission.WRITE_NOTIFICATIONS,
        # Premium additional permissions
        Permission.READ_FINANCE,
        Permission.WRITE_FINANCE,
        Permission.READ_INVENTORY,
        Permission.WRITE_INVENTORY
    ],
    UserRole.EXECUTIVE: [
        # All Premium permissions
        Permission.READ_CLIENTS,
        Permission.WRITE_CLIENTS,
        Permission.READ_APPOINTMENTS,
        Permission.WRITE_APPOINTMENTS,
        Permission.READ_NOTIFICATIONS,
        Permission.WRITE_NOTIFICATIONS,
        Permission.READ_FINANCE,
        Permission.WRITE_FINANCE,
        Permission.READ_INVENTORY,
        Permission.WRITE_INVENTORY,
        # Executive exclusive permissions
        Permission.READ_AI_DESIGN,
        Permission.WRITE_AI_DESIGN,
        Permission.ADMIN_USERS,
        Permission.ADMIN_SYSTEM
    ]
}

def hash_password(password: str) -> str:
    """Generate bcrypt hash for password storage."""
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against stored hash."""
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Generate JWT access token with user claims."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: Dict[str, Any]) -> str:
    """Generate JWT refresh token for token rotation."""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=JWT_REFRESH_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
    return encoded_jwt

def verify_token(token: str, token_type: str = "access") -> Optional[Dict[str, Any]]:
    """Verify and decode JWT token with type validation."""
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        if payload.get("type") != token_type:
            return None
        return payload
    except JWTError:
        return None

def get_user_id_from_token(token: str) -> Optional[str]:
    """Extract user ID from validated token."""
    payload = verify_token(token)
    if payload:
        return payload.get("sub")
    return None

def check_permission(required_permission: Permission):
    """Decorator factory for endpoint permission checking."""
    def permission_checker(current_user: Dict[str, Any]):
        user_role = UserRole(current_user.get("role"))
        user_permissions = ROLE_PERMISSIONS.get(user_role, [])
        
        if required_permission not in user_permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required: {required_permission}"
            )
        return current_user
    return permission_checker

def require_role(required_role: UserRole):
    """Decorator factory for role-based endpoint protection."""
    def role_checker(current_user: Dict[str, Any]):
        user_role = UserRole(current_user.get("role"))
        
        role_hierarchy = {
            UserRole.STANDARD: 1,
            UserRole.PREMIUM: 2,
            UserRole.EXECUTIVE: 3
        }
        
        if role_hierarchy[user_role] < role_hierarchy[required_role]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role {required_role} or higher required. Current role: {user_role}"
            )
        return current_user
    return role_checker

async def get_current_user_from_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Extract current user from JWT token."""
    token = credentials.credentials
    payload = verify_token(token)
    
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"}
        )
    
    return {
        "id": payload.get("sub"),
        "email": payload.get("email"),
        "role": payload.get("role"),
        "subscription_plan": payload.get("subscription_plan"),
        "subscription_status": payload.get("subscription_status")
    }