from fastapi import FastAPI, APIRouter, HTTPException, UploadFile, File
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timedelta
import base64
from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent
from enum import Enum

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ.get('DB_NAME', 'backend')]

# Emergent LLM key
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

# Create the main app without a prefix
app = FastAPI(title="Chic Harmony - PMU Studio Management System")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# =============================================================================
# ENUMS
# =============================================================================

class AppointmentStatus(str, Enum):
    SCHEDULED = "scheduled"
    CONFIRMED = "confirmed"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"

class ServiceType(str, Enum):
    EYEBROW_MICROBLADING = "eyebrow_microblading"
    EYEBROW_POWDER_BROWS = "eyebrow_powder_brows"
    EYEBROW_TOUCH_UP = "eyebrow_touch_up"
    LIP_BLUSH = "lip_blush"
    LIP_NEUTRALIZATION = "lip_neutralization"
    EYELINER = "eyeliner"
    CONSULTATION = "consultation"
    REMOVAL = "removal"

class RecurrenceType(str, Enum):
    NONE = "none"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    TOUCH_UP = "touch_up"

class TransactionType(str, Enum):
    INCOME = "income"
    EXPENSE = "expense"

class ExpenseCategory(str, Enum):
    SUPPLIES = "supplies"
    RENT = "rent"
    MARKETING = "marketing"
    EQUIPMENT = "equipment"
    TRAINING = "training"
    INSURANCE = "insurance"
    OTHER = "other"

class ProductCategory(str, Enum):
    PIGMENTS = "pigments"
    NEEDLES = "needles"
    MACHINES = "machines"
    ANESTHETICS = "anesthetics"
    AFTERCARE = "aftercare"
    DISPOSABLES = "disposables"
    EQUIPMENT = "equipment"
    OTHER = "other"

class StockMovementType(str, Enum):
    IN = "in"      # Purchase/Restock
    OUT = "out"    # Usage/Service
    ADJUSTMENT = "adjustment"  # Manual adjustment

# =============================================================================
# MODELS
# =============================================================================

class ClientCreate(BaseModel):
    first_name: str
    last_name: str
    email: str
    phone: str
    date_of_birth: Optional[str] = None
    skin_tone: Optional[str] = None
    hair_color: Optional[str] = None
    eye_color: Optional[str] = None
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    notes: Optional[str] = None

class ClientUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    skin_tone: Optional[str] = None
    hair_color: Optional[str] = None
    eye_color: Optional[str] = None
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    notes: Optional[str] = None

class Client(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    first_name: str
    last_name: str
    email: str
    phone: str
    date_of_birth: Optional[str] = None
    skin_tone: Optional[str] = None
    hair_color: Optional[str] = None
    eye_color: Optional[str] = None
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    notes: Optional[str] = None
    photos: List[dict] = []
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class AppointmentCreate(BaseModel):
    client_id: str
    service_type: ServiceType
    appointment_date: datetime
    duration_minutes: int = 120
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: RecurrenceType = RecurrenceType.NONE
    send_reminders: bool = True

class AppointmentUpdate(BaseModel):
    client_id: Optional[str] = None
    service_type: Optional[ServiceType] = None
    appointment_date: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    status: Optional[AppointmentStatus] = None
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: Optional[RecurrenceType] = None
    send_reminders: Optional[bool] = None

class Appointment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_id: str
    service_type: ServiceType
    appointment_date: datetime
    duration_minutes: int = 120
    status: AppointmentStatus = AppointmentStatus.SCHEDULED
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: RecurrenceType = RecurrenceType.NONE
    parent_appointment_id: Optional[str] = None
    send_reminders: bool = True
    reminder_sent: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class AppointmentWithClient(BaseModel):
    id: str
    client_id: str
    client_name: str
    client_email: str
    client_phone: str
    service_type: ServiceType
    appointment_date: datetime
    duration_minutes: int
    status: AppointmentStatus
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: RecurrenceType
    send_reminders: bool
    reminder_sent: bool
    created_at: datetime
    updated_at: datetime

class TransactionCreate(BaseModel):
    type: TransactionType
    amount: float
    description: str
    category: str
    date: Optional[datetime] = None
    appointment_id: Optional[str] = None
    client_id: Optional[str] = None

class TransactionUpdate(BaseModel):
    type: Optional[TransactionType] = None
    amount: Optional[float] = None
    description: Optional[str] = None
    category: Optional[str] = None
    date: Optional[datetime] = None

class Transaction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: TransactionType
    amount: float
    description: str
    category: str
    date: datetime
    appointment_id: Optional[str] = None
    client_id: Optional[str] = None
    client_name: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class ProductCreate(BaseModel):
    name: str
    brand: Optional[str] = None
    category: ProductCategory
    sku: Optional[str] = None
    unit: str = "piece"  # piece, ml, gram, set
    current_stock: float = 0
    min_stock_level: float = 5
    max_stock_level: float = 100
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    notes: Optional[str] = None

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    brand: Optional[str] = None
    category: Optional[ProductCategory] = None
    sku: Optional[str] = None
    unit: Optional[str] = None
    min_stock_level: Optional[float] = None
    max_stock_level: Optional[float] = None
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    notes: Optional[str] = None

class Product(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    brand: Optional[str] = None
    category: ProductCategory
    sku: Optional[str] = None
    unit: str = "piece"
    current_stock: float = 0
    min_stock_level: float = 5
    max_stock_level: float = 100
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    notes: Optional[str] = None
    total_purchased: float = 0
    total_used: float = 0
    last_restocked: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class StockMovementCreate(BaseModel):
    product_id: str
    type: StockMovementType
    quantity: float
    reason: str
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    appointment_id: Optional[str] = None
    notes: Optional[str] = None

class StockMovement(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    product_id: str
    type: StockMovementType
    quantity: float
    reason: str
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    appointment_id: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ServiceRecipe(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    service_type: ServiceType
    product_requirements: List[dict]  # [{"product_id": "xxx", "quantity": 2.5}, ...]
    created_at: datetime = Field(default_factory=datetime.utcnow)

class PhotoAnalysis(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_id: str
    photo_base64: str
    analysis_type: str
    ai_analysis: Optional[dict] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

# =============================================================================
# AI ANALYSIS FUNCTIONS
# =============================================================================

async def analyze_facial_symmetry(image_base64: str) -> dict:
    """Analyze facial symmetry using AI vision model"""
    try:
        if not EMERGENT_LLM_KEY:
            return {"error": "AI analysis not available - no API key configured"}
        
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"symmetry_{uuid.uuid4()}",
            system_message="You are an expert permanent makeup artist analyzing facial symmetry for PMU procedures."
        ).with_model("openai", "gpt-4o")
        
        image_content = ImageContent(image_base64=image_base64)
        
        user_message = UserMessage(
            text="""Analyze this face for permanent makeup symmetry:
            1. Evaluate eyebrow symmetry (shape, height, arch position)
            2. Assess facial proportions relevant to PMU
            3. Identify any asymmetries that need consideration
            4. Provide specific recommendations for eyebrow design
            5. Rate overall facial symmetry (1-10 scale)
            
            Return analysis in JSON format with:
            - symmetry_score (1-10)
            - eyebrow_analysis
            - recommendations
            - key_measurements""",
            file_contents=[image_content]
        )
        
        response = await chat.send_message(user_message)
        
        return {
            "ai_response": response,
            "analysis_type": "facial_symmetry",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logging.error(f"AI analysis error: {str(e)}")
        return {"error": f"AI analysis failed: {str(e)}"}

async def analyze_skin_color(image_base64: str) -> dict:
    """Analyze skin color and tone for pigment recommendations"""
    try:
        if not EMERGENT_LLM_KEY:
            return {"error": "AI analysis not available - no API key configured"}
        
        chat = LlmChat(
            api_key=EMERGENT_LLM_KEY,
            session_id=f"color_{uuid.uuid4()}",
            system_message="You are a permanent makeup color expert analyzing skin tones for pigment selection."
        ).with_model("openai", "gpt-4o")
        
        image_content = ImageContent(image_base64=image_base64)
        
        user_message = UserMessage(
            text="""Analyze this skin for PMU pigment selection:
            1. Identify dominant skin tone (warm, cool, neutral)
            2. Determine undertones (yellow, red, blue, olive)
            3. Assess skin saturation and depth
            4. Recommend suitable pigment colors for eyebrows
            5. Suggest pigment mixing ratios
            
            Return analysis in JSON format with:
            - skin_tone_category
            - undertones
            - recommended_pigments
            - mixing_ratios
            - application_notes""",
            file_contents=[image_content]
        )
        
        response = await chat.send_message(user_message)
        
        return {
            "ai_response": response,
            "analysis_type": "color_analysis",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logging.error(f"Color analysis error: {str(e)}")
        return {"error": f"Color analysis failed: {str(e)}"}

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def get_service_duration(service_type: ServiceType) -> int:
    """Get default duration for service type in minutes"""
    duration_map = {
        ServiceType.EYEBROW_MICROBLADING: 180,
        ServiceType.EYEBROW_POWDER_BROWS: 150,
        ServiceType.EYEBROW_TOUCH_UP: 90,
        ServiceType.LIP_BLUSH: 120,
        ServiceType.LIP_NEUTRALIZATION: 90,
        ServiceType.EYELINER: 120,
        ServiceType.CONSULTATION: 60,
        ServiceType.REMOVAL: 90,
    }
    return duration_map.get(service_type, 120)

def get_service_price(service_type: ServiceType) -> float:
    """Get default price for service type"""
    price_map = {
        ServiceType.EYEBROW_MICROBLADING: 450.0,
        ServiceType.EYEBROW_POWDER_BROWS: 400.0,
        ServiceType.EYEBROW_TOUCH_UP: 150.0,
        ServiceType.LIP_BLUSH: 500.0,
        ServiceType.LIP_NEUTRALIZATION: 300.0,
        ServiceType.EYELINER: 350.0,
        ServiceType.CONSULTATION: 50.0,
        ServiceType.REMOVAL: 200.0,
    }
    return price_map.get(service_type, 300.0)

async def get_service_products(service_type: ServiceType) -> List[dict]:
    """Get required products for a service type with quantities"""
    # Default product requirements for each service
    service_requirements = {
        ServiceType.EYEBROW_MICROBLADING: [
            {"category": "pigments", "quantity": 0.5, "reason": "Pigment usage"},
            {"category": "needles", "quantity": 1, "reason": "Disposable needle"},
            {"category": "anesthetics", "quantity": 0.2, "reason": "Numbing cream"},
            {"category": "disposables", "quantity": 1, "reason": "Disposable items"},
        ],
        ServiceType.EYEBROW_POWDER_BROWS: [
            {"category": "pigments", "quantity": 0.3, "reason": "Pigment usage"},
            {"category": "needles", "quantity": 1, "reason": "Disposable needle"},
            {"category": "anesthetics", "quantity": 0.2, "reason": "Numbing cream"},
            {"category": "disposables", "quantity": 1, "reason": "Disposable items"},
        ],
        ServiceType.LIP_BLUSH: [
            {"category": "pigments", "quantity": 0.4, "reason": "Lip pigment usage"},
            {"category": "needles", "quantity": 1, "reason": "Disposable needle"},
            {"category": "anesthetics", "quantity": 0.3, "reason": "Lip numbing"},
            {"category": "disposables", "quantity": 1, "reason": "Disposable items"},
        ],
    }
    
    return service_requirements.get(service_type, [])

async def deduct_inventory_for_service(service_type: ServiceType, appointment_id: str) -> List[str]:
    """Automatically deduct inventory when service is completed"""
    deduction_records = []
    
    try:
        # Get service requirements
        requirements = await get_service_products(service_type)
        
        for requirement in requirements:
            # Find products in this category with available stock
            products = await db.products.find({
                "category": requirement["category"],
                "current_stock": {"$gte": requirement["quantity"]}
            }).sort("current_stock", -1).to_list(10)
            
            if products:
                # Use the product with most stock
                product = products[0]
                
                # Create stock movement record
                movement = StockMovement(
                    product_id=product["id"],
                    type=StockMovementType.OUT,
                    quantity=requirement["quantity"],
                    reason=f"Service: {service_type.value}",
                    appointment_id=appointment_id
                )
                
                # Insert movement record
                await db.stock_movements.insert_one(movement.dict())
                
                # Update product stock
                new_stock = product["current_stock"] - requirement["quantity"]
                await db.products.update_one(
                    {"id": product["id"]},
                    {"$set": {
                        "current_stock": new_stock,
                        "total_used": product.get("total_used", 0) + requirement["quantity"],
                        "updated_at": datetime.utcnow()
                    }}
                )
                
                deduction_records.append(movement.id)
    
    except Exception as e:
        logging.error(f"Error deducting inventory: {str(e)}")
    
    return deduction_records

async def create_recurring_appointments(appointment: Appointment) -> List[str]:
    """Create recurring appointments based on recurrence type"""
    if appointment.recurrence_type == RecurrenceType.NONE:
        return []
    
    recurring_appointments = []
    base_date = appointment.appointment_date
    
    if appointment.recurrence_type == RecurrenceType.TOUCH_UP:
        touch_up_date = base_date + timedelta(weeks=6)
        touch_up = Appointment(
            client_id=appointment.client_id,
            service_type=ServiceType.EYEBROW_TOUCH_UP,
            appointment_date=touch_up_date,
            duration_minutes=90,
            status=AppointmentStatus.SCHEDULED,
            notes=f"Touch-up for {appointment.service_type.value}",
            price=get_service_price(ServiceType.EYEBROW_TOUCH_UP),
            recurrence_type=RecurrenceType.NONE,
            parent_appointment_id=appointment.id,
            send_reminders=True
        )
        
        result = await db.appointments.insert_one(touch_up.dict())
        if result.inserted_id:
            recurring_appointments.append(touch_up.id)
    
    return recurring_appointments

async def create_income_transaction(appointment: Appointment, client_name: str) -> str:
    """Create income transaction when appointment is completed"""
    if appointment.status != AppointmentStatus.COMPLETED or not appointment.price:
        return ""
    
    transaction = Transaction(
        type=TransactionType.INCOME,
        amount=appointment.price,
        description=f"{appointment.service_type.value.replace('_', ' ').title()}",
        category="service",
        date=appointment.appointment_date,
        appointment_id=appointment.id,
        client_id=appointment.client_id,
        client_name=client_name
    )
    
    result = await db.transactions.insert_one(transaction.dict())
    return transaction.id if result.inserted_id else ""

# =============================================================================
# CLIENT MANAGEMENT ROUTES
# =============================================================================

@api_router.get("/")
async def root():
    return {"message": "Chic Harmony - PMU Studio Management System API", "version": "4.0.0"}

@api_router.post("/clients", response_model=Client)
async def create_client(client_data: ClientCreate):
    """Create a new client"""
    try:
        client_dict = client_data.dict()
        client = Client(**client_dict)
        
        result = await db.clients.insert_one(client.dict())
        
        if result.inserted_id:
            return client
        else:
            raise HTTPException(status_code=500, detail="Failed to create client")
            
    except Exception as e:
        logging.error(f"Error creating client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/clients", response_model=List[Client])
async def get_clients():
    """Get all clients"""
    try:
        clients = await db.clients.find().to_list(1000)
        return [Client(**client) for client in clients]
    except Exception as e:
        logging.error(f"Error fetching clients: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/clients/{client_id}", response_model=Client)
async def get_client(client_id: str):
    """Get a specific client by ID"""
    try:
        client = await db.clients.find_one({"id": client_id})
        if not client:
            raise HTTPException(status_code=404, detail="Client not found")
        return Client(**client)
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error fetching client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/clients/{client_id}", response_model=Client)
async def update_client(client_id: str, client_update: ClientUpdate):
    """Update a client"""
    try:
        update_data = {k: v for k, v in client_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        result = await db.clients.update_one(
            {"id": client_id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Client not found")
        
        updated_client = await db.clients.find_one({"id": client_id})
        return Client(**updated_client)
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error updating client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/clients/{client_id}")
async def delete_client(client_id: str):
    """Delete a client"""
    try:
        result = await db.clients.delete_one({"id": client_id})
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Client not found")
        
        return {"message": "Client deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error deleting client: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# APPOINTMENT MANAGEMENT ROUTES
# =============================================================================

@api_router.post("/appointments", response_model=Appointment)
async def create_appointment(appointment_data: AppointmentCreate):
    """Create a new appointment"""
    try:
        client = await db.clients.find_one({"id": appointment_data.client_id})
        if not client:
            raise HTTPException(status_code=404, detail="Client not found")
        
        appointment_dict = appointment_data.dict()
        if not appointment_dict.get("duration_minutes"):
            appointment_dict["duration_minutes"] = get_service_duration(appointment_data.service_type)
        if not appointment_dict.get("price"):
            appointment_dict["price"] = get_service_price(appointment_data.service_type)
        
        appointment = Appointment(**appointment_dict)
        
        result = await db.appointments.insert_one(appointment.dict())
        
        if result.inserted_id:
            recurring_ids = await create_recurring_appointments(appointment)
            return appointment
        else:
            raise HTTPException(status_code=500, detail="Failed to create appointment")
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error creating appointment: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/appointments", response_model=List[AppointmentWithClient])
async def get_appointments(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    client_id: Optional[str] = None,
    status: Optional[AppointmentStatus] = None
):
    """Get appointments with optional filters"""
    try:
        query = {}
        
        if start_date and end_date:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query["appointment_date"] = {"$gte": start, "$lte": end}
        
        if client_id:
            query["client_id"] = client_id
            
        if status:
            query["status"] = status
        
        appointments = await db.appointments.find(query).to_list(1000)
        
        enriched_appointments = []
        for appointment in appointments:
            client = await db.clients.find_one({"id": appointment["client_id"]})
            if client:
                appointment_with_client = AppointmentWithClient(
                    **appointment,
                    client_name=f"{client['first_name']} {client['last_name']}",
                    client_email=client["email"],
                    client_phone=client["phone"]
                )
                enriched_appointments.append(appointment_with_client)
        
        return enriched_appointments
        
    except Exception as e:
        logging.error(f"Error fetching appointments: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/appointments/{appointment_id}", response_model=AppointmentWithClient)
async def get_appointment(appointment_id: str):
    """Get a specific appointment by ID"""
    try:
        appointment = await db.appointments.find_one({"id": appointment_id})
        if not appointment:
            raise HTTPException(status_code=404, detail="Appointment not found")
        
        client = await db.clients.find_one({"id": appointment["client_id"]})
        if not client:
            raise HTTPException(status_code=404, detail="Client not found")
        
        appointment_with_client = AppointmentWithClient(
            **appointment,
            client_name=f"{client['first_name']} {client['last_name']}",
            client_email=client["email"],
            client_phone=client["phone"]
        )
        
        return appointment_with_client
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error fetching appointment: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/appointments/{appointment_id}", response_model=Appointment)
async def update_appointment(appointment_id: str, appointment_update: AppointmentUpdate):
    """Update an appointment"""
    try:
        current_appointment = await db.appointments.find_one({"id": appointment_id})
        if not current_appointment:
            raise HTTPException(status_code=404, detail="Appointment not found")
        
        update_data = {k: v for k, v in appointment_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        # Check if status is being changed to completed
        if (update_data.get("status") == AppointmentStatus.COMPLETED and 
            current_appointment.get("status") != AppointmentStatus.COMPLETED):
            
            # Create income transaction
            client = await db.clients.find_one({"id": current_appointment["client_id"]})
            if client:
                client_name = f"{client['first_name']} {client['last_name']}"
                appointment_obj = Appointment(**{**current_appointment, **update_data})
                await create_income_transaction(appointment_obj, client_name)
                
                # Deduct inventory automatically
                await deduct_inventory_for_service(
                    ServiceType(current_appointment["service_type"]), 
                    appointment_id
                )
        
        result = await db.appointments.update_one(
            {"id": appointment_id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Appointment not found")
        
        updated_appointment = await db.appointments.find_one({"id": appointment_id})
        return Appointment(**updated_appointment)
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error updating appointment: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/appointments/{appointment_id}")
async def delete_appointment(appointment_id: str):
    """Delete an appointment"""
    try:
        result = await db.appointments.delete_one({"id": appointment_id})
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Appointment not found")
        
        return {"message": "Appointment deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error deleting appointment: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/calendar/{year}/{month}")
async def get_calendar_data(year: int, month: int):
    """Get calendar data for a specific month"""
    try:
        start_date = datetime(year, month, 1)
        if month == 12:
            end_date = datetime(year + 1, 1, 1) - timedelta(days=1)
        else:
            end_date = datetime(year, month + 1, 1) - timedelta(days=1)
        
        appointments = await db.appointments.find({
            "appointment_date": {
                "$gte": start_date,
                "$lte": end_date
            }
        }).to_list(1000)
        
        calendar_data = {}
        for appointment in appointments:
            date_key = appointment["appointment_date"].strftime("%Y-%m-%d")
            if date_key not in calendar_data:
                calendar_data[date_key] = []
            
            client = await db.clients.find_one({"id": appointment["client_id"]})
            if client:
                calendar_data[date_key].append({
                    "id": appointment["id"],
                    "client_name": f"{client['first_name']} {client['last_name']}",
                    "service_type": appointment["service_type"],
                    "time": appointment["appointment_date"].strftime("%H:%M"),
                    "duration": appointment["duration_minutes"],
                    "status": appointment["status"]
                })
        
        return {
            "year": year,
            "month": month,
            "appointments": calendar_data
        }
        
    except Exception as e:
        logging.error(f"Error fetching calendar data: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/availability/{date}")
async def get_availability(date: str):
    """Get available time slots for a specific date"""
    try:
        target_date = datetime.fromisoformat(date.replace('Z', '+00:00')).date()
        
        working_hours = {
            0: {"start": "09:00", "end": "17:00"},
            1: {"start": "09:00", "end": "17:00"},
            2: {"start": "09:00", "end": "17:00"},
            3: {"start": "09:00", "end": "17:00"},
            4: {"start": "09:00", "end": "17:00"},
            5: {"start": "09:00", "end": "15:00"},
            6: {"start": "closed", "end": "closed"}
        }
        
        day_of_week = target_date.weekday()
        day_hours = working_hours.get(day_of_week, {"start": "closed", "end": "closed"})
        
        if day_hours["start"] == "closed":
            return {"available_slots": [], "message": "Closed on this day"}
        
        start_datetime = datetime.combine(target_date, datetime.min.time())
        end_datetime = start_datetime + timedelta(days=1)
        
        appointments = await db.appointments.find({
            "appointment_date": {
                "$gte": start_datetime,
                "$lt": end_datetime
            },
            "status": {"$in": [AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED]}
        }).to_list(100)
        
        available_slots = []
        current_time = datetime.strptime(day_hours["start"], "%H:%M").time()
        end_time = datetime.strptime(day_hours["end"], "%H:%M").time()
        
        while current_time < end_time:
            slot_datetime = datetime.combine(target_date, current_time)
            is_available = True
            
            for appointment in appointments:
                appt_start = appointment["appointment_date"]
                appt_end = appt_start + timedelta(minutes=appointment["duration_minutes"])
                
                if appt_start <= slot_datetime < appt_end:
                    is_available = False
                    break
            
            if is_available:
                available_slots.append(current_time.strftime("%H:%M"))
            
            current_hour = current_time.hour + 1
            if current_hour < 24:
                current_time = current_time.replace(hour=current_hour)
            else:
                break
        
        return {"available_slots": available_slots}
        
    except Exception as e:
        logging.error(f"Error fetching availability: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# FINANCE MANAGEMENT ROUTES
# =============================================================================

@api_router.post("/finance/transactions", response_model=Transaction)
async def create_transaction(transaction_data: TransactionCreate):
    """Create a new financial transaction"""
    try:
        transaction_dict = transaction_data.dict()
        if not transaction_dict.get("date"):
            transaction_dict["date"] = datetime.utcnow()
        
        if transaction_dict.get("client_id"):
            client = await db.clients.find_one({"id": transaction_dict["client_id"]})
            if client:
                transaction_dict["client_name"] = f"{client['first_name']} {client['last_name']}"
        
        transaction = Transaction(**transaction_dict)
        
        result = await db.transactions.insert_one(transaction.dict())
        
        if result.inserted_id:
            return transaction
        else:
            raise HTTPException(status_code=500, detail="Failed to create transaction")
            
    except Exception as e:
        logging.error(f"Error creating transaction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/finance/transactions", response_model=List[Transaction])
async def get_transactions(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    type: Optional[TransactionType] = None,
    category: Optional[str] = None,
    limit: Optional[int] = 100
):
    """Get financial transactions with optional filters"""
    try:
        query = {}
        
        if start_date and end_date:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query["date"] = {"$gte": start, "$lte": end}
        
        if type:
            query["type"] = type
            
        if category:
            query["category"] = category
        
        transactions = await db.transactions.find(query).sort("date", -1).to_list(limit)
        return [Transaction(**transaction) for transaction in transactions]
        
    except Exception as e:
        logging.error(f"Error fetching transactions: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/finance/stats")
async def get_finance_stats():
    """Get financial statistics and analytics"""
    try:
        now = datetime.utcnow()
        today = now.date()
        week_start = today - timedelta(days=today.weekday())
        month_start = today.replace(day=1)
        
        today_start = datetime.combine(today, datetime.min.time())
        today_end = today_start + timedelta(days=1)
        week_start_dt = datetime.combine(week_start, datetime.min.time())
        week_end_dt = week_start_dt + timedelta(days=7)
        month_start_dt = datetime.combine(month_start, datetime.min.time())
        month_end_dt = month_start_dt + timedelta(days=32)
        month_end_dt = month_end_dt.replace(day=1) - timedelta(days=1)
        month_end_dt = datetime.combine(month_end_dt, datetime.max.time())
        
        # Get income stats
        daily_income_result = await db.transactions.aggregate([
            {"$match": {
                "type": "income",
                "date": {"$gte": today_start, "$lt": today_end}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        daily_income = daily_income_result[0]["total"] if daily_income_result else 0
        
        weekly_income_result = await db.transactions.aggregate([
            {"$match": {
                "type": "income",
                "date": {"$gte": week_start_dt, "$lt": week_end_dt}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        weekly_income = weekly_income_result[0]["total"] if weekly_income_result else 0
        
        monthly_income_result = await db.transactions.aggregate([
            {"$match": {
                "type": "income",
                "date": {"$gte": month_start_dt, "$lt": month_end_dt}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        monthly_income = monthly_income_result[0]["total"] if monthly_income_result else 0
        
        # Get expense stats
        daily_expenses_result = await db.transactions.aggregate([
            {"$match": {
                "type": "expense",
                "date": {"$gte": today_start, "$lt": today_end}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        daily_expenses = daily_expenses_result[0]["total"] if daily_expenses_result else 0
        
        weekly_expenses_result = await db.transactions.aggregate([
            {"$match": {
                "type": "expense",
                "date": {"$gte": week_start_dt, "$lt": week_end_dt}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        weekly_expenses = weekly_expenses_result[0]["total"] if weekly_expenses_result else 0
        
        monthly_expenses_result = await db.transactions.aggregate([
            {"$match": {
                "type": "expense",
                "date": {"$gte": month_start_dt, "$lt": month_end_dt}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        monthly_expenses = monthly_expenses_result[0]["total"] if monthly_expenses_result else 0
        
        # Get top services
        top_services_result = await db.transactions.aggregate([
            {"$match": {
                "type": "income",
                "category": "service",
                "date": {"$gte": month_start_dt, "$lt": month_end_dt}
            }},
            {"$group": {
                "_id": "$description",
                "count": {"$sum": 1},
                "revenue": {"$sum": "$amount"}
            }},
            {"$sort": {"revenue": -1}},
            {"$limit": 5}
        ]).to_list(5)
        
        top_services = [
            {
                "service": service["_id"],
                "count": service["count"],
                "revenue": service["revenue"]
            }
            for service in top_services_result
        ]
        
        # Get expense categories
        expense_categories_result = await db.transactions.aggregate([
            {"$match": {
                "type": "expense",
                "date": {"$gte": month_start_dt, "$lt": month_end_dt}
            }},
            {"$group": {
                "_id": "$category",
                "total": {"$sum": "$amount"}
            }},
            {"$sort": {"total": -1}}
        ]).to_list(10)
        
        total_monthly_expenses = sum(cat["total"] for cat in expense_categories_result)
        expense_categories = [
            {
                "category": cat["_id"],
                "total": cat["total"],
                "percentage": round((cat["total"] / total_monthly_expenses * 100) if total_monthly_expenses > 0 else 0)
            }
            for cat in expense_categories_result
        ]
        
        return {
            "daily_income": daily_income,
            "weekly_income": weekly_income,
            "monthly_income": monthly_income,
            "daily_expenses": daily_expenses,
            "weekly_expenses": weekly_expenses,
            "monthly_expenses": monthly_expenses,
            "net_profit_week": weekly_income - weekly_expenses,
            "net_profit_month": monthly_income - monthly_expenses,
            "top_services": top_services,
            "expense_categories": expense_categories
        }
        
    except Exception as e:
        logging.error(f"Error fetching finance stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/finance/transactions/{transaction_id}", response_model=Transaction)
async def update_transaction(transaction_id: str, transaction_update: TransactionUpdate):
    """Update a financial transaction"""
    try:
        update_data = {k: v for k, v in transaction_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        result = await db.transactions.update_one(
            {"id": transaction_id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Transaction not found")
        
        updated_transaction = await db.transactions.find_one({"id": transaction_id})
        return Transaction(**updated_transaction)
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error updating transaction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/finance/transactions/{transaction_id}")
async def delete_transaction(transaction_id: str):
    """Delete a financial transaction"""
    try:
        result = await db.transactions.delete_one({"id": transaction_id})
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Transaction not found")
        
        return {"message": "Transaction deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error deleting transaction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# INVENTORY MANAGEMENT ROUTES
# =============================================================================

@api_router.post("/inventory/products", response_model=Product)
async def create_product(product_data: ProductCreate):
    """Create a new inventory product"""
    try:
        product = Product(**product_data.dict())
        
        result = await db.products.insert_one(product.dict())
        
        if result.inserted_id:
            return product
        else:
            raise HTTPException(status_code=500, detail="Failed to create product")
            
    except Exception as e:
        logging.error(f"Error creating product: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/inventory/products", response_model=List[Product])
async def get_products(
    category: Optional[ProductCategory] = None,
    low_stock: Optional[bool] = None
):
    """Get inventory products with optional filters"""
    try:
        query = {}
        
        if category:
            query["category"] = category
            
        if low_stock:
            # Add a condition to find products below minimum stock level
            query["$expr"] = {"$lt": ["$current_stock", "$min_stock_level"]}
        
        products = await db.products.find(query).to_list(1000)
        return [Product(**product) for product in products]
        
    except Exception as e:
        logging.error(f"Error fetching products: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/inventory/products/{product_id}", response_model=Product)
async def get_product(product_id: str):
    """Get a specific product by ID"""
    try:
        product = await db.products.find_one({"id": product_id})
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")
        return Product(**product)
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error fetching product: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/inventory/products/{product_id}", response_model=Product)
async def update_product(product_id: str, product_update: ProductUpdate):
    """Update a product"""
    try:
        update_data = {k: v for k, v in product_update.dict().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        result = await db.products.update_one(
            {"id": product_id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Product not found")
        
        updated_product = await db.products.find_one({"id": product_id})
        return Product(**updated_product)
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error updating product: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/inventory/products/{product_id}")
async def delete_product(product_id: str):
    """Delete a product"""
    try:
        result = await db.products.delete_one({"id": product_id})
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Product not found")
        
        return {"message": "Product deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error deleting product: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/inventory/movements", response_model=StockMovement)
async def create_stock_movement(movement_data: StockMovementCreate):
    """Create a stock movement (in/out/adjustment)"""
    try:
        # Verify product exists
        product = await db.products.find_one({"id": movement_data.product_id})
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")
        
        movement = StockMovement(**movement_data.dict())
        
        # Insert movement record
        result = await db.stock_movements.insert_one(movement.dict())
        
        if result.inserted_id:
            # Update product stock based on movement type
            stock_change = 0
            if movement.type == StockMovementType.IN:
                stock_change = movement.quantity
            elif movement.type == StockMovementType.OUT:
                stock_change = -movement.quantity
            elif movement.type == StockMovementType.ADJUSTMENT:
                # For adjustments, the quantity is the final amount, not the change
                stock_change = movement.quantity - product["current_stock"]
            
            new_stock = product["current_stock"] + stock_change
            update_data = {
                "current_stock": max(0, new_stock),  # Don't allow negative stock
                "updated_at": datetime.utcnow()
            }
            
            # Update totals
            if movement.type == StockMovementType.IN:
                update_data["total_purchased"] = product.get("total_purchased", 0) + movement.quantity
                update_data["last_restocked"] = datetime.utcnow()
            elif movement.type == StockMovementType.OUT:
                update_data["total_used"] = product.get("total_used", 0) + movement.quantity
            
            # Update cost per unit if provided
            if movement.cost_per_unit:
                update_data["cost_per_unit"] = movement.cost_per_unit
            
            await db.products.update_one(
                {"id": movement_data.product_id},
                {"$set": update_data}
            )
            
            # Create expense transaction for purchases
            if movement.type == StockMovementType.IN and movement.cost_per_unit:
                total_cost = movement.quantity * movement.cost_per_unit
                expense_transaction = Transaction(
                    type=TransactionType.EXPENSE,
                    amount=total_cost,
                    description=f"Purchase: {product['name']}",
                    category="supplies",
                    date=datetime.utcnow()
                )
                await db.transactions.insert_one(expense_transaction.dict())
            
            return movement
        else:
            raise HTTPException(status_code=500, detail="Failed to create stock movement")
            
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error creating stock movement: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/inventory/movements")
async def get_stock_movements(
    product_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: Optional[int] = 100
):
    """Get stock movements with optional filters"""
    try:
        query = {}
        
        if product_id:
            query["product_id"] = product_id
            
        if start_date and end_date:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query["created_at"] = {"$gte": start, "$lte": end}
        
        movements = await db.stock_movements.find(query).sort("created_at", -1).to_list(limit)
        
        # Enrich with product information
        enriched_movements = []
        for movement in movements:
            product = await db.products.find_one({"id": movement["product_id"]})
            if product:
                enriched_movement = {
                    **movement,
                    "product_name": product["name"],
                    "product_category": product["category"]
                }
                enriched_movements.append(enriched_movement)
        
        return enriched_movements
        
    except Exception as e:
        logging.error(f"Error fetching stock movements: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/inventory/alerts")
async def get_inventory_alerts():
    """Get low stock and other inventory alerts"""
    try:
        # Get low stock products
        low_stock_products = await db.products.find({
            "$expr": {"$lt": ["$current_stock", "$min_stock_level"]}
        }).to_list(100)
        
        # Get out of stock products
        out_of_stock_products = await db.products.find({
            "current_stock": {"$lte": 0}
        }).to_list(100)
        
        # Get products not restocked in 30 days
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        needs_restock_products = await db.products.find({
            "$or": [
                {"last_restocked": {"$lt": thirty_days_ago}},
                {"last_restocked": None}
            ]
        }).to_list(100)
        
        return {
            "low_stock_count": len(low_stock_products),
            "out_of_stock_count": len(out_of_stock_products),
            "needs_restock_count": len(needs_restock_products),
            "low_stock_products": [Product(**p) for p in low_stock_products],
            "out_of_stock_products": [Product(**p) for p in out_of_stock_products],
            "needs_restock_products": [Product(**p) for p in needs_restock_products]
        }
        
    except Exception as e:
        logging.error(f"Error fetching inventory alerts: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/inventory/stats")
async def get_inventory_stats():
    """Get inventory statistics and analytics"""
    try:
        # Get total products count
        total_products = await db.products.count_documents({})
        
        # Get total inventory value
        products = await db.products.find({}).to_list(1000)
        total_value = sum(
            p.get("current_stock", 0) * p.get("cost_per_unit", 0) 
            for p in products if p.get("cost_per_unit")
        )
        
        # Get category breakdown
        category_stats = await db.products.aggregate([
            {"$group": {
                "_id": "$category",
                "count": {"$sum": 1},
                "total_stock": {"$sum": "$current_stock"},
                "avg_stock": {"$avg": "$current_stock"}
            }},
            {"$sort": {"count": -1}}
        ]).to_list(10)
        
        # Get low stock count
        low_stock_count = await db.products.count_documents({
            "$expr": {"$lt": ["$current_stock", "$min_stock_level"]}
        })
        
        # Get most used products (highest total_used)
        most_used_products = await db.products.find({}).sort("total_used", -1).limit(5).to_list(5)
        
        return {
            "total_products": total_products,
            "total_inventory_value": total_value,
            "low_stock_alerts": low_stock_count,
            "category_breakdown": category_stats,
            "most_used_products": [
                {
                    "name": p["name"],
                    "category": p["category"],
                    "total_used": p.get("total_used", 0),
                    "current_stock": p["current_stock"]
                }
                for p in most_used_products
            ]
        }
        
    except Exception as e:
        logging.error(f"Error fetching inventory stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# PHOTO MANAGEMENT ROUTES
# =============================================================================

@api_router.post("/clients/{client_id}/photos")
async def add_client_photo(client_id: str, photo_base64: str, photo_type: str = "general"):
    """Add a photo to a client's profile"""
    try:
        client = await db.clients.find_one({"id": client_id})
        if not client:
            raise HTTPException(status_code=404, detail="Client not found")
        
        photo_record = {
            "id": str(uuid.uuid4()),
            "photo_base64": photo_base64,
            "photo_type": photo_type,
            "uploaded_at": datetime.utcnow().isoformat()
        }
        
        await db.clients.update_one(
            {"id": client_id},
            {"$push": {"photos": photo_record}}
        )
        
        return {"message": "Photo added successfully", "photo_id": photo_record["id"]}
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error adding photo: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/clients/{client_id}/photos/{photo_id}/analyze")
async def analyze_client_photo(client_id: str, photo_id: str, analysis_type: str = "symmetry"):
    """Analyze a client's photo using AI"""
    try:
        client = await db.clients.find_one({"id": client_id})
        if not client:
            raise HTTPException(status_code=404, detail="Client not found")
        
        photo = None
        for p in client.get("photos", []):
            if p["id"] == photo_id:
                photo = p
                break
        
        if not photo:
            raise HTTPException(status_code=404, detail="Photo not found")
        
        if analysis_type == "symmetry":
            analysis_result = await analyze_facial_symmetry(photo["photo_base64"])
        elif analysis_type == "color":
            analysis_result = await analyze_skin_color(photo["photo_base64"])
        else:
            raise HTTPException(status_code=400, detail="Invalid analysis type")
        
        analysis_record = PhotoAnalysis(
            client_id=client_id,
            photo_base64=photo["photo_base64"],
            analysis_type=analysis_type,
            ai_analysis=analysis_result
        )
        
        await db.photo_analyses.insert_one(analysis_record.dict())
        
        return analysis_result
        
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error analyzing photo: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/clients/{client_id}/analyses")
async def get_client_analyses(client_id: str):
    """Get all AI analyses for a client"""
    try:
        analyses = await db.photo_analyses.find({"client_id": client_id}).to_list(100)
        return [PhotoAnalysis(**analysis) for analysis in analyses]
    except Exception as e:
        logging.error(f"Error fetching analyses: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# STATISTICS ROUTES
# =============================================================================

@api_router.get("/stats/dashboard")
async def get_dashboard_stats():
    """Get dashboard statistics"""
    try:
        # Count clients
        total_clients = await db.clients.count_documents({})
        
        # Count today's appointments
        today = datetime.now().date()
        today_start = datetime.combine(today, datetime.min.time())
        today_end = today_start + timedelta(days=1)
        
        today_appointments = await db.appointments.count_documents({
            "appointment_date": {"$gte": today_start, "$lt": today_end}
        })
        
        # Count this week's appointments
        week_start = today_start - timedelta(days=today.weekday())
        week_end = week_start + timedelta(days=7)
        
        week_appointments = await db.appointments.count_documents({
            "appointment_date": {"$gte": week_start, "$lt": week_end}
        })
        
        # Count total analyses
        total_analyses = await db.photo_analyses.count_documents({})
        
        # Get weekly income
        weekly_income_result = await db.transactions.aggregate([
            {"$match": {
                "type": "income",
                "date": {"$gte": week_start, "$lt": week_end}
            }},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
        ]).to_list(1)
        weekly_income = weekly_income_result[0]["total"] if weekly_income_result else 0
        
        # Get inventory alerts
        low_stock_count = await db.products.count_documents({
            "$expr": {"$lt": ["$current_stock", "$min_stock_level"]}
        })
        
        return {
            "total_clients": total_clients,
            "today_appointments": today_appointments,
            "week_appointments": week_appointments,
            "total_analyses": total_analyses,
            "weekly_income": weekly_income,
            "low_stock_alerts": low_stock_count
        }
        
    except Exception as e:
        logging.error(f"Error fetching dashboard stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()