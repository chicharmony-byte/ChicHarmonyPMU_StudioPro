from typing import Dict, List, Optional, Any, Tuple
import json
import logging
from datetime import datetime, timedelta, date
from pathlib import Path
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
import pandas as pd
from io import BytesIO
import base64

load_dotenv()
logger = logging.getLogger(__name__)

class AnalyticsService:
    def __init__(self, db):
        self.db = db
        
        # KPIs y métricas disponibles
        self.available_metrics = {
            "financial": [
                "total_revenue",
                "monthly_revenue", 
                "average_ticket",
                "revenue_by_service",
                "profit_margins",
                "payment_methods"
            ],
            "clients": [
                "total_clients",
                "new_clients_monthly",
                "client_retention_rate",
                "client_demographics",
                "client_satisfaction",
                "referral_sources"
            ],
            "appointments": [
                "total_appointments",
                "appointment_completion_rate",
                "no_show_rate",
                "peak_hours",
                "service_popularity",
                "booking_sources"
            ],
            "business": [
                "growth_rate",
                "capacity_utilization",
                "average_session_duration",
                "seasonal_trends",
                "competitive_analysis"
            ]
        }
        
        # Tipos de reportes
        self.report_types = {
            "daily": "Reporte Diario",
            "weekly": "Reporte Semanal", 
            "monthly": "Reporte Mensual",
            "quarterly": "Reporte Trimestral",
            "yearly": "Reporte Anual",
            "custom": "Reporte Personalizado"
        }

    async def get_dashboard_overview(self, user_id: str, date_range: Dict[str, str] = None) -> Dict[str, Any]:
        """Obtener resumen general del dashboard"""
        try:
            # Determinar rango de fechas
            if not date_range:
                end_date = datetime.utcnow()
                start_date = end_date - timedelta(days=30)
            else:
                start_date = datetime.fromisoformat(date_range["start_date"].replace('Z', '+00:00'))
                end_date = datetime.fromisoformat(date_range["end_date"].replace('Z', '+00:00'))

            # Obtener métricas principales
            financial_metrics = await self._get_financial_metrics(user_id, start_date, end_date)
            client_metrics = await self._get_client_metrics(user_id, start_date, end_date)
            appointment_metrics = await self._get_appointment_metrics(user_id, start_date, end_date)
            
            # Calcular KPIs principales
            kpis = await self._calculate_main_kpis(user_id, start_date, end_date)
            
            return {
                "success": True,
                "period": {
                    "start_date": start_date.isoformat(),
                    "end_date": end_date.isoformat(),
                    "days": (end_date - start_date).days
                },
                "kpis": kpis,
                "financial": financial_metrics,
                "clients": client_metrics,
                "appointments": appointment_metrics,
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error generating dashboard overview: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _get_financial_metrics(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Obtener métricas financieras"""
        try:
            # Obtener transacciones del período
            transactions = await self.db.transactions.find({
                "user_id": user_id,
                "date": {"$gte": start_date, "$lte": end_date}
            }).to_list(1000)
            
            if not transactions:
                return self._empty_financial_metrics()
            
            # Calcular métricas
            total_revenue = sum(t.get("amount", 0) for t in transactions if t.get("type") == "income")
            total_expenses = sum(t.get("amount", 0) for t in transactions if t.get("type") == "expense")
            net_profit = total_revenue - total_expenses
            
            # Ingresos por servicio
            revenue_by_service = {}
            for t in transactions:
                if t.get("type") == "income":
                    service = t.get("category", "Otros")
                    revenue_by_service[service] = revenue_by_service.get(service, 0) + t.get("amount", 0)
            
            # Calcular tendencia (comparar con período anterior)
            previous_start = start_date - timedelta(days=(end_date - start_date).days)
            previous_transactions = await self.db.transactions.find({
                "user_id": user_id,
                "date": {"$gte": previous_start, "$lt": start_date}
            }).to_list(1000)
            
            previous_revenue = sum(t.get("amount", 0) for t in previous_transactions if t.get("type") == "income")
            revenue_growth = ((total_revenue - previous_revenue) / previous_revenue * 100) if previous_revenue > 0 else 0
            
            return {
                "total_revenue": total_revenue,
                "total_expenses": total_expenses,  
                "net_profit": net_profit,
                "profit_margin": (net_profit / total_revenue * 100) if total_revenue > 0 else 0,
                "revenue_growth": round(revenue_growth, 2),
                "revenue_by_service": revenue_by_service,
                "transaction_count": len(transactions),
                "average_transaction": total_revenue / len([t for t in transactions if t.get("type") == "income"]) if len([t for t in transactions if t.get("type") == "income"]) > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Error calculating financial metrics: {str(e)}")
            return self._empty_financial_metrics()

    async def _get_client_metrics(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Obtener métricas de clientes"""
        try:
            # Total de clientes
            total_clients = await self.db.clients.count_documents({"user_id": user_id})
            
            # Nuevos clientes en el período
            new_clients = await self.db.clients.count_documents({
                "user_id": user_id,
                "created_at": {"$gte": start_date, "$lte": end_date}
            })
            
            # Clientes activos (con citas en el período)
            active_clients_pipeline = [
                {"$match": {
                    "user_id": user_id,
                    "appointment_date": {"$gte": start_date, "$lte": end_date}
                }},
                {"$group": {"_id": "$client_id"}},
                {"$count": "active_clients"}
            ]
            
            active_result = await self.db.appointments.aggregate(active_clients_pipeline).to_list(1)
            active_clients = active_result[0]["active_clients"] if active_result else 0
            
            # Calcular retención
            retention_rate = (active_clients / total_clients * 100) if total_clients > 0 else 0
            
            return {
                "total_clients": total_clients,
                "new_clients": new_clients,
                "active_clients": active_clients,
                "retention_rate": round(retention_rate, 2),
                "growth_rate": round((new_clients / max(total_clients - new_clients, 1)) * 100, 2)
            }
            
        except Exception as e:
            logger.error(f"Error calculating client metrics: {str(e)}")
            return {
                "total_clients": 0,
                "new_clients": 0, 
                "active_clients": 0,
                "retention_rate": 0,
                "growth_rate": 0
            }

    async def _get_appointment_metrics(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Obtener métricas de citas"""
        try:
            # Total de citas programadas
            total_appointments = await self.db.appointments.count_documents({
                "user_id": user_id,
                "appointment_date": {"$gte": start_date, "$lte": end_date}
            })
            
            # Citas completadas
            completed_appointments = await self.db.appointments.count_documents({
                "user_id": user_id,
                "appointment_date": {"$gte": start_date, "$lte": end_date},
                "status": "completed"
            })
            
            # Citas canceladas/no show
            cancelled_appointments = await self.db.appointments.count_documents({
                "user_id": user_id,
                "appointment_date": {"$gte": start_date, "$lte": end_date},
                "status": {"$in": ["cancelled", "no_show"]}
            })
            
            # Tasa de finalización
            completion_rate = (completed_appointments / total_appointments * 100) if total_appointments > 0 else 0
            no_show_rate = (cancelled_appointments / total_appointments * 100) if total_appointments > 0 else 0
            
            # Servicios más populares
            popular_services_pipeline = [
                {"$match": {
                    "user_id": user_id,
                    "appointment_date": {"$gte": start_date, "$lte": end_date}
                }},
                {"$group": {
                    "_id": "$service_type",
                    "count": {"$sum": 1}
                }},
                {"$sort": {"count": -1}},
                {"$limit": 5}
            ]
            
            popular_services = await self.db.appointments.aggregate(popular_services_pipeline).to_list(5)
            
            return {
                "total_appointments": total_appointments,
                "completed_appointments": completed_appointments,
                "cancelled_appointments": cancelled_appointments,
                "completion_rate": round(completion_rate, 2),
                "no_show_rate": round(no_show_rate, 2), 
                "popular_services": [{"service": s["_id"], "count": s["count"]} for s in popular_services]
            }
            
        except Exception as e:
            logger.error(f"Error calculating appointment metrics: {str(e)}")
            return {
                "total_appointments": 0,
                "completed_appointments": 0,
                "cancelled_appointments": 0,
                "completion_rate": 0,
                "no_show_rate": 0,
                "popular_services": []
            }

    async def _calculate_main_kpis(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Calcular KPIs principales del negocio"""
        try:
            # Obtener datos básicos
            total_clients = await self.db.clients.count_documents({"user_id": user_id})
            total_appointments = await self.db.appointments.count_documents({
                "user_id": user_id,
                "appointment_date": {"$gte": start_date, "$lte": end_date}
            })
            
            # Calcular ingresos
            revenue_pipeline = [
                {"$match": {
                    "user_id": user_id,
                    "type": "income",
                    "date": {"$gte": start_date, "$lte": end_date}
                }},
                {"$group": {
                    "_id": None,
                    "total": {"$sum": "$amount"}
                }}
            ]
            
            revenue_result = await self.db.transactions.aggregate(revenue_pipeline).to_list(1)
            total_revenue = revenue_result[0]["total"] if revenue_result else 0
            
            # KPIs calculados
            days_in_period = (end_date - start_date).days
            daily_average_revenue = total_revenue / max(days_in_period, 1)
            average_per_client = total_revenue / max(total_clients, 1)
            
            return {
                "total_revenue": total_revenue,
                "daily_average_revenue": round(daily_average_revenue, 2),
                "average_per_client": round(average_per_client, 2),
                "appointments_per_day": round(total_appointments / max(days_in_period, 1), 2),
                "client_base": total_clients,
                "period_days": days_in_period
            }
            
        except Exception as e:
            logger.error(f"Error calculating main KPIs: {str(e)}")
            return {
                "total_revenue": 0,
                "daily_average_revenue": 0,
                "average_per_client": 0,
                "appointments_per_day": 0,
                "client_base": 0,
                "period_days": 0
            }

    async def generate_detailed_report(self, user_id: str, report_type: str, date_range: Dict[str, str]) -> Dict[str, Any]:
        """Generar reporte detallado"""
        try:
            start_date = datetime.fromisoformat(date_range["start_date"].replace('Z', '+00:00'))
            end_date = datetime.fromisoformat(date_range["end_date"].replace('Z', '+00:00'))
            
            # Obtener datos completos
            dashboard_data = await self.get_dashboard_overview(user_id, date_range)
            
            # Datos adicionales para reporte detallado
            detailed_data = await self._get_detailed_analytics(user_id, start_date, end_date)
            
            # Generar insights y recomendaciones
            insights = await self._generate_business_insights(user_id, start_date, end_date)
            
            report = {
                "success": True,
                "report_type": report_type,
                "generated_at": datetime.utcnow().isoformat(),
                "period": dashboard_data["period"],
                "executive_summary": {
                    "total_revenue": dashboard_data["financial"]["total_revenue"],
                    "growth_rate": dashboard_data["financial"]["revenue_growth"],
                    "client_base": dashboard_data["clients"]["total_clients"],
                    "appointments": dashboard_data["appointments"]["total_appointments"]
                },
                "financial_analysis": dashboard_data["financial"],
                "client_analysis": dashboard_data["clients"],
                "appointment_analysis": dashboard_data["appointments"],
                "detailed_metrics": detailed_data,
                "business_insights": insights,
                "recommendations": await self._generate_recommendations(dashboard_data)
            }
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating detailed report: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _get_detailed_analytics(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Obtener analytics detallados"""
        try:
            # Análisis por días de la semana
            weekday_analysis = await self._analyze_weekday_patterns(user_id, start_date, end_date)
            
            # Análisis por horas del día
            hourly_analysis = await self._analyze_hourly_patterns(user_id, start_date, end_date)
            
            # Tendencias mensuales
            monthly_trends = await self._analyze_monthly_trends(user_id, start_date, end_date)
            
            return {
                "weekday_patterns": weekday_analysis,
                "hourly_patterns": hourly_analysis,
                "monthly_trends": monthly_trends,
                "peak_performance": await self._identify_peak_periods(user_id, start_date, end_date)
            }
            
        except Exception as e:
            logger.error(f"Error getting detailed analytics: {str(e)}")
            return {}

    async def _analyze_weekday_patterns(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Analizar patrones por día de la semana"""
        try:
            pipeline = [
                {"$match": {
                    "user_id": user_id,
                    "appointment_date": {"$gte": start_date, "$lte": end_date}
                }},
                {"$group": {
                    "_id": {"$dayOfWeek": "$appointment_date"},
                    "appointments": {"$sum": 1},
                    "revenue": {"$sum": "$price"}
                }},
                {"$sort": {"_id": 1}}
            ]
            
            results = await self.db.appointments.aggregate(pipeline).to_list(7)
            
            weekdays = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"]
            weekday_data = {}
            
            for result in results:
                day_index = result["_id"] - 1  # MongoDB dayOfWeek is 1-based
                weekday_data[weekdays[day_index]] = {
                    "appointments": result["appointments"],
                    "revenue": result.get("revenue", 0)
                }
            
            return weekday_data
            
        except Exception as e:
            logger.error(f"Error analyzing weekday patterns: {str(e)}")
            return {}

    async def _analyze_hourly_patterns(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Analizar patrones por hora del día"""
        try:
            pipeline = [
                {"$match": {
                    "user_id": user_id,
                    "appointment_date": {"$gte": start_date, "$lte": end_date}
                }},
                {"$group": {
                    "_id": {"$hour": "$appointment_date"},
                    "appointments": {"$sum": 1}
                }},
                {"$sort": {"_id": 1}}
            ]
            
            results = await self.db.appointments.aggregate(pipeline).to_list(24)
            
            hourly_data = {}
            for result in results:
                hour = f"{result['_id']:02d}:00"
                hourly_data[hour] = result["appointments"]
            
            return hourly_data
            
        except Exception as e:
            logger.error(f"Error analyzing hourly patterns: {str(e)}")
            return {}

    async def _analyze_monthly_trends(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Analizar tendencias mensuales"""
        try:
            pipeline = [
                {"$match": {
                    "user_id": user_id,
                    "date": {"$gte": start_date, "$lte": end_date},
                    "type": "income"
                }},
                {"$group": {
                    "_id": {
                        "year": {"$year": "$date"},
                        "month": {"$month": "$date"}
                    },
                    "revenue": {"$sum": "$amount"},
                    "transactions": {"$sum": 1}
                }},
                {"$sort": {"_id.year": 1, "_id.month": 1}}
            ]
            
            results = await self.db.transactions.aggregate(pipeline).to_list(12)
            
            monthly_data = []
            for result in results:
                month_name = datetime(result["_id"]["year"], result["_id"]["month"], 1).strftime("%B %Y")
                monthly_data.append({
                    "month": month_name,
                    "revenue": result["revenue"],
                    "transactions": result["transactions"]
                })
            
            return monthly_data
            
        except Exception as e:
            logger.error(f"Error analyzing monthly trends: {str(e)}")
            return []

    async def _identify_peak_periods(self, user_id: str, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Identificar períodos pico"""
        try:
            # Mejor día de la semana
            weekday_data = await self._analyze_weekday_patterns(user_id, start_date, end_date)
            best_weekday = max(weekday_data.items(), key=lambda x: x[1].get("revenue", 0)) if weekday_data else ("N/A", {"revenue": 0})
            
            # Mejor hora del día
            hourly_data = await self._analyze_hourly_patterns(user_id, start_date, end_date)
            best_hour = max(hourly_data.items(), key=lambda x: x[1]) if hourly_data else ("N/A", 0)
            
            return {
                "best_weekday": {
                    "day": best_weekday[0],
                    "revenue": best_weekday[1].get("revenue", 0),
                    "appointments": best_weekday[1].get("appointments", 0)
                },
                "best_hour": {
                    "hour": best_hour[0],
                    "appointments": best_hour[1]
                }
            }
            
        except Exception as e:
            logger.error(f"Error identifying peak periods: {str(e)}")
            return {}

    async def _generate_business_insights(self, user_id: str, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """Generar insights de negocio"""
        try:
            insights = []
            
            # Obtener datos para insights
            financial_data = await self._get_financial_metrics(user_id, start_date, end_date)
            client_data = await self._get_client_metrics(user_id, start_date, end_date)
            appointment_data = await self._get_appointment_metrics(user_id, start_date, end_date)
            
            # Insight de crecimiento
            if financial_data["revenue_growth"] > 10:
                insights.append({
                    "type": "positive",
                    "title": "Crecimiento Excelente",
                    "description": f"Tus ingresos han crecido un {financial_data['revenue_growth']:.1f}% comparado con el período anterior.",
                    "recommendation": "Mantén las estrategias actuales y considera expandir tu capacidad."
                })
            elif financial_data["revenue_growth"] < -5:
                insights.append({
                    "type": "warning",
                    "title": "Necesita Atención",
                    "description": f"Los ingresos han disminuido un {abs(financial_data['revenue_growth']):.1f}%.",
                    "recommendation": "Revisa tu estrategia de marketing y ofertas de servicios."
                })
            
            # Insight de retención
            if client_data["retention_rate"] > 80:
                insights.append({
                    "type": "positive",
                    "title": "Alta Retención de Clientes",
                    "description": f"Tienes una excelente retención del {client_data['retention_rate']:.1f}%.",
                    "recommendation": "Aprovecha para implementar un programa de referidos."
                })
            elif client_data["retention_rate"] < 50:
                insights.append({
                    "type": "warning", 
                    "title": "Baja Retención",
                    "description": f"Solo el {client_data['retention_rate']:.1f}% de clientes regresan.",
                    "recommendation": "Mejora el seguimiento post-tratamiento y la experiencia del cliente."
                })
            
            # Insight de eficiencia
            if appointment_data["no_show_rate"] > 20:
                insights.append({
                    "type": "warning",
                    "title": "Alta Tasa de No-Shows",
                    "description": f"El {appointment_data['no_show_rate']:.1f}% de citas no se cumplen.",
                    "recommendation": "Implementa recordatorios automáticos y políticas de cancelación."
                })
            
            return insights
            
        except Exception as e:
            logger.error(f"Error generating business insights: {str(e)}")
            return []

    async def _generate_recommendations(self, dashboard_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generar recomendaciones basadas en datos"""
        try:
            recommendations = []
            
            financial = dashboard_data.get("financial", {})
            clients = dashboard_data.get("clients", {})
            appointments = dashboard_data.get("appointments", {})
            
            # Recomendaciones financieras
            if financial.get("profit_margin", 0) < 30:
                recommendations.append({
                    "category": "financial",
                    "priority": "high",
                    "title": "Mejorar Margen de Ganancia",
                    "description": "Tu margen de ganancia está por debajo del 30% recomendado.",
                    "actions": [
                        "Revisar estructura de precios",
                        "Optimizar costos operativos", 
                        "Ofrecer servicios premium"
                    ]
                })
            
            # Recomendaciones de clientes
            if clients.get("new_clients", 0) < 5:
                recommendations.append({
                    "category": "marketing",
                    "priority": "medium",
                    "title": "Aumentar Adquisición de Clientes",
                    "description": "Pocos clientes nuevos este período.",
                    "actions": [
                        "Intensificar marketing digital",
                        "Implementar programa de referidos",
                        "Ofrecer promociones para nuevos clientes"
                    ]
                })
            
            # Recomendaciones operativas
            if appointments.get("completion_rate", 0) < 90:
                recommendations.append({
                    "category": "operations", 
                    "priority": "high",
                    "title": "Mejorar Tasa de Finalización",
                    "description": "Muchas citas no se están completando.",
                    "actions": [
                        "Implementar sistema de recordatorios",
                        "Mejorar proceso de confirmación",
                        "Analizar causas de cancelaciones"
                    ]
                })
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {str(e)}")
            return []

    def _empty_financial_metrics(self) -> Dict[str, Any]:
        """Retornar métricas financieras vacías"""
        return {
            "total_revenue": 0,
            "total_expenses": 0,
            "net_profit": 0,
            "profit_margin": 0,
            "revenue_growth": 0,
            "revenue_by_service": {},
            "transaction_count": 0,
            "average_transaction": 0
        }

    async def export_report_to_excel(self, report_data: Dict[str, Any]) -> str:
        """Exportar reporte a Excel y retornar base64"""
        try:
            # Crear archivo Excel en memoria
            output = BytesIO()
            
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # Hoja de resumen ejecutivo
                summary_df = pd.DataFrame([report_data.get("executive_summary", {})])
                summary_df.to_excel(writer, sheet_name='Resumen Ejecutivo', index=False)
                
                # Hoja de análisis financiero
                if "financial_analysis" in report_data:
                    financial_df = pd.DataFrame([report_data["financial_analysis"]])
                    financial_df.to_excel(writer, sheet_name='Análisis Financiero', index=False)
                
                # Hoja de clientes
                if "client_analysis" in report_data:
                    client_df = pd.DataFrame([report_data["client_analysis"]])
                    client_df.to_excel(writer, sheet_name='Análisis de Clientes', index=False)
                
                # Hoja de citas
                if "appointment_analysis" in report_data:
                    appointment_df = pd.DataFrame([report_data["appointment_analysis"]])
                    appointment_df.to_excel(writer, sheet_name='Análisis de Citas', index=False)
            
            # Convertir a base64
            excel_bytes = output.getvalue()
            excel_base64 = base64.b64encode(excel_bytes).decode('utf-8')
            
            return excel_base64
            
        except Exception as e:
            logger.error(f"Error exporting to Excel: {str(e)}")
            return ""

# Esta función se inicializará cuando se importe el módulo
def create_analytics_service(db):
    return AnalyticsService(db)