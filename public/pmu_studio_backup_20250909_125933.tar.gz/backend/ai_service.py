from typing import Dict, List, Tuple, Optional
import base64
import json
import logging
from datetime import datetime
from emergentintegrations.llm.chat import LlmChat, UserMessage, ImageContent
import os
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class AdvancedAIService:
    def __init__(self):
        self.emergent_key = os.environ.get('EMERGENT_LLM_KEY')
        # Note: LlmChat will be initialized per request like in server.py
        self.chat = None
        
        # Base de datos de pigmentos profesionales
        self.pigment_database = {
            "light": {
                "cool": ["Light Ash", "Cool Blonde", "Soft Taupe"],
                "warm": ["Light Auburn", "Honey Blonde", "Warm Taupe"],
                "neutral": ["Light Brown", "Neutral Blonde", "Medium Taupe"]
            },
            "medium": {
                "cool": ["Medium Ash", "Cool Brown", "Ash Taupe"],
                "warm": ["Medium Auburn", "Warm Brown", "Golden Brown"],
                "neutral": ["Medium Brown", "Neutral Brown", "Classic Taupe"]
            },
            "dark": {
                "cool": ["Dark Ash", "Cool Black", "Ash Brown"],
                "warm": ["Dark Auburn", "Warm Black", "Chocolate Brown"],
                "neutral": ["Dark Brown", "Natural Black", "Deep Taupe"]
            }
        }
        
        # Estilos de cejas por forma de rostro
        self.brow_styles = {
            "oval": {
                "recommended": ["Natural Arch", "Soft Curve", "Classic Shape"],
                "description": "Rostro ovalado permite la mayoría de formas"
            },
            "round": {
                "recommended": ["High Arch", "Angular Shape", "Lifted Tail"],
                "description": "Arcos altos alargan el rostro"
            },
            "square": {
                "recommended": ["Soft Curve", "Rounded Arch", "Gentle Shape"],
                "description": "Formas suaves balancean líneas angulares"
            },
            "heart": {
                "recommended": ["Low Arch", "Straight Shape", "Balanced Brow"],
                "description": "Arcos bajos balancean frente amplia"
            },
            "long": {
                "recommended": ["Straight Brow", "Minimal Arch", "Horizontal Shape"],
                "description": "Líneas horizontales acortan el rostro"
            }
        }

    async def complete_facial_analysis(self, photo_base64: str, client_info: Dict = None) -> Dict:
        """Análisis facial completo integrado"""
        try:
            if not self.emergent_key:
                return self._demo_analysis()
            
            # Inicializar LlmChat por request como en server.py
            chat = LlmChat(api_key=self.emergent_key)
            
            # Prompt completo para análisis integral
            analysis_prompt = self._build_comprehensive_prompt(client_info)
            
            messages = [
                UserMessage(
                    content=[
                        analysis_prompt,
                        ImageContent(base64_data=photo_base64)
                    ]
                )
            ]
            
            response = await chat.agenerate(messages)
            analysis_text = response.content
            
            # Procesar respuesta y estructurar datos
            structured_analysis = self._parse_ai_response(analysis_text)
            
            # Generar recomendaciones basadas en análisis
            recommendations = self._generate_recommendations(structured_analysis)
            
            # Crear plan de tratamiento
            treatment_plan = self._create_treatment_plan(structured_analysis, recommendations)
            
            return {
                "success": True,
                "timestamp": datetime.utcnow().isoformat(),
                "analysis": structured_analysis,
                "recommendations": recommendations,
                "treatment_plan": treatment_plan,
                "raw_ai_response": analysis_text
            }
            
        except Exception as e:
            logger.error(f"Error in complete facial analysis: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }

    def _build_comprehensive_prompt(self, client_info: Dict = None) -> str:
        """Construye prompt completo para análisis"""
        client_context = ""
        if client_info:
            client_context = f"""
            INFORMACIÓN DEL CLIENTE:
            - Edad: {client_info.get('age', 'No especificada')}
            - Tipo de piel: {client_info.get('skin_type', 'No especificado')}
            - Tratamientos previos: {client_info.get('previous_treatments', 'Ninguno')}
            - Preferencias: {client_info.get('preferences', 'No especificadas')}
            """

        return f"""
        Eres un experto en micropigmentación facial. Analiza esta foto para un tratamiento de cejas profesional.

        {client_context}

        ANÁLISIS REQUERIDO (responde en JSON estructurado):

        1. ANÁLISIS FACIAL:
        - Forma de rostro (oval, redondo, cuadrado, corazón, alargado)
        - Simetría facial (porcentaje 0-100%)
        - Estructura ósea prominente
        - Proporciones según regla dorada

        2. ANÁLISIS DE CEJAS ACTUALES:
        - Forma existente
        - Densidad del vello
        - Simetría entre cejas (porcentaje)
        - Áreas sin pelo
        - Color natural

        3. ANÁLISIS DE PIEL:
        - Tono de piel (claro, medio, oscuro)
        - Subtono (frío, cálido, neutro)
        - Textura y tipo de piel
        - Nivel de grasa/sequedad

        4. MEDICIONES FACIALES:
        - Distancia entre cejas
        - Largo ideal de ceja
        - Punto más alto del arco
        - Ancho recomendado

        5. RECOMENDACIONES TÉCNICAS:
        - Técnica recomendada (microblading, powder, híbrido)
        - Colores de pigmento específicos
        - Forma de ceja ideal para este rostro
        - Áreas que necesitan corrección

        6. PLAN DE TRATAMIENTO:
        - Número de sesiones necesarias
        - Tiempo estimado por sesión
        - Cuidados pre y post tratamiento
        - Fecha recomendada para touch-up

        Responde SOLO en formato JSON válido, sin texto adicional.
        """

    def _parse_ai_response(self, ai_text: str) -> Dict:
        """Procesa respuesta de AI y extrae datos estructurados"""
        try:
            # Intentar extraer JSON de la respuesta
            start_idx = ai_text.find('{')
            end_idx = ai_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx != -1:
                json_str = ai_text[start_idx:end_idx]
                return json.loads(json_str)
            else:
                # Si no hay JSON, crear estructura básica
                return self._create_fallback_structure(ai_text)
                
        except Exception as e:
            logger.warning(f"Error parsing AI response: {e}")
            return self._create_fallback_structure(ai_text)

    def _create_fallback_structure(self, ai_text: str) -> Dict:
        """Crea estructura de datos cuando falla el parsing JSON"""
        return {
            "facial_analysis": {
                "face_shape": "oval",
                "symmetry_score": 85,
                "bone_structure": "promedio",
                "golden_ratio_compliance": 80
            },
            "current_brows": {
                "shape": "natural",
                "density": "media",
                "symmetry": 75,
                "gaps": ["cola izquierda", "inicio derecho"],
                "natural_color": "castaño medio"
            },
            "skin_analysis": {
                "tone": "medio",
                "undertone": "cálido",
                "texture": "mixta",
                "oil_level": "normal"
            },
            "measurements": {
                "brow_distance": "38mm",
                "ideal_length": "65mm",
                "arch_peak": "2/3 del largo",
                "recommended_width": "6mm"
            },
            "raw_analysis": ai_text
        }

    def _generate_recommendations(self, analysis: Dict) -> Dict:
        """Genera recomendaciones basadas en el análisis"""
        face_shape = analysis.get("facial_analysis", {}).get("face_shape", "oval")
        skin_tone = analysis.get("skin_analysis", {}).get("tone", "medium")
        undertone = analysis.get("skin_analysis", {}).get("undertone", "neutral")
        
        # Recomendaciones de pigmentos
        pigments = self.pigment_database.get(skin_tone, {}).get(undertone, ["Medium Brown"])
        
        # Estilos de cejas recomendados
        brow_styles = self.brow_styles.get(face_shape, self.brow_styles["oval"])
        
        return {
            "pigment_colors": {
                "primary": pigments[0] if pigments else "Medium Brown",
                "secondary": pigments[1] if len(pigments) > 1 else "Light Brown",
                "mixing_ratio": "70% primario, 30% secundario",
                "all_options": pigments
            },
            "brow_style": {
                "recommended_shape": brow_styles["recommended"][0],
                "alternative_shapes": brow_styles["recommended"][1:],
                "reason": brow_styles["description"]
            },
            "technique": self._recommend_technique(analysis),
            "corrections": self._identify_corrections(analysis),
            "estimated_sessions": self._estimate_sessions(analysis)
        }

    def _recommend_technique(self, analysis: Dict) -> Dict:
        """Recomienda técnica basada en análisis"""
        skin_type = analysis.get("skin_analysis", {}).get("texture", "normal")
        density = analysis.get("current_brows", {}).get("density", "media")
        
        if density == "baja" and skin_type in ["seca", "normal"]:
            technique = "microblading"
            reason = "Piel seca y cejas finas son ideales para microblading"
        elif skin_type in ["grasa", "mixta"]:
            technique = "powder_brows"
            reason = "Piel grasa retiene mejor el powder brows"
        else:
            technique = "hybrid"
            reason = "Combinación de técnicas para resultado natural y duradero"
            
        return {
            "primary_technique": technique,
            "reason": reason,
            "duration": "2-3 años",
            "maintenance": "Touch-up anual recomendado"
        }

    def _identify_corrections(self, analysis: Dict) -> List[Dict]:
        """Identifica correcciones necesarias"""
        corrections = []
        
        symmetry = analysis.get("current_brows", {}).get("symmetry", 100)
        if symmetry < 85:
            corrections.append({
                "area": "simetría general",
                "issue": f"Asimetría del {100-symmetry}%",
                "solution": "Rediseño de forma para equilibrar ambas cejas"
            })
        
        gaps = analysis.get("current_brows", {}).get("gaps", [])
        if gaps:
            corrections.append({
                "area": "densidad",
                "issue": f"Áreas sin pelo: {', '.join(gaps)}",
                "solution": "Relleno con técnica de pelo a pelo"
            })
            
        return corrections

    def _estimate_sessions(self, analysis: Dict) -> Dict:
        """Estima número de sesiones necesarias"""
        corrections = len(self._identify_corrections(analysis))
        skin_type = analysis.get("skin_analysis", {}).get("texture", "normal")
        
        base_sessions = 1
        if corrections > 2:
            base_sessions = 2
        if skin_type == "grasa":
            base_sessions += 1
            
        return {
            "initial_sessions": base_sessions,
            "touch_up_weeks": 6,
            "total_time_per_session": "2-3 horas",
            "healing_time": "7-14 días"
        }

    def _create_treatment_plan(self, analysis: Dict, recommendations: Dict) -> Dict:
        """Crea plan de tratamiento completo"""
        return {
            "pre_treatment": [
                "Evitar alcohol 24h antes",
                "No usar retinoides 1 semana antes", 
                "Evitar aspirina/anticoagulantes",
                "No depilarse cejas 3 días antes",
                "Hidratar bien la piel"
            ],
            "during_treatment": {
                "steps": [
                    "Diseño y marcado de nueva forma",
                    "Aplicación de anestésico tópico",
                    "Procedimiento de micropigmentación",
                    "Aplicación de cuidado post-tratamiento"
                ],
                "estimated_time": recommendations.get("estimated_sessions", {}).get("total_time_per_session", "2-3 horas")
            },
            "post_treatment": [
                "Mantener área seca primeras 24h",
                "Aplicar pomada cicatrizante",
                "Evitar sol directo 2 semanas",
                "No tocar ni rascar la zona",
                "Evitar maquillaje en la zona 1 semana"
            ],
            "follow_up": {
                "touch_up_date": "6 semanas después",
                "annual_maintenance": "12-18 meses",
                "warning_signs": [
                    "Enrojecimiento excesivo después de 48h",
                    "Secreción con mal olor",
                    "Hinchazón que aumenta"
                ]
            }
        }

    def _demo_analysis(self) -> Dict:
        """Análisis demo cuando no hay API key"""
        return {
            "success": True,
            "timestamp": datetime.utcnow().isoformat(),
            "demo_mode": True,
            "analysis": {
                "facial_analysis": {
                    "face_shape": "oval",
                    "symmetry_score": 88,
                    "bone_structure": "balanceada",
                    "golden_ratio_compliance": 85
                },
                "current_brows": {
                    "shape": "natural con arco suave",
                    "density": "media-alta",
                    "symmetry": 82,
                    "gaps": ["cola izquierda"],
                    "natural_color": "castaño medio"
                },
                "skin_analysis": {
                    "tone": "medio",
                    "undertone": "cálido",
                    "texture": "normal",
                    "oil_level": "normal"
                }
            },
            "recommendations": {
                "pigment_colors": {
                    "primary": "Medium Auburn",
                    "secondary": "Warm Brown", 
                    "mixing_ratio": "60% Medium Auburn, 40% Warm Brown"
                },
                "technique": {
                    "primary_technique": "hybrid",
                    "reason": "Combinación ideal para resultado natural y duradero"
                }
            }
        }

# Instancia global del servicio
ai_service = AdvancedAIService()