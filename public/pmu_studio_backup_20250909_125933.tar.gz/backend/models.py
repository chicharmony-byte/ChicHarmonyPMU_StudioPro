from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime
from enum import Enum
import uuid

# User and Authentication Models
class UserRole(str, Enum):
    STANDARD = "standard"
    PREMIUM = "premium"
    EXECUTIVE = "executive"

class SubscriptionPlan(str, Enum):
    STANDARD_MONTHLY = "standard_monthly"
    STANDARD_ANNUAL = "standard_annual"
    PREMIUM_MONTHLY = "premium_monthly"
    PREMIUM_ANNUAL = "premium_annual"
    EXECUTIVE_MONTHLY = "executive_monthly"
    EXECUTIVE_ANNUAL = "executive_annual"

class SubscriptionStatus(str, Enum):
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    UNPAID = "unpaid"
    TRIALING = "trialing"

class UserRegistration(BaseModel):
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=8)
    confirm_password: str
    role: Optional[UserRole] = UserRole.STANDARD

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    email: str
    username: str
    role: UserRole
    subscription_plan: Optional[SubscriptionPlan] = None
    subscription_status: Optional[SubscriptionStatus] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    username: str
    hashed_password: str
    role: UserRole = UserRole.STANDARD
    subscription_plan: Optional[SubscriptionPlan] = None
    subscription_status: Optional[SubscriptionStatus] = None
    stripe_customer_id: Optional[str] = None
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class RefreshToken(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    token_hash: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime
    is_revoked: bool = False

# Subscription and Payment Models
class SubscriptionCreate(BaseModel):
    plan: SubscriptionPlan
    payment_method_id: str

class PaymentIntent(BaseModel):
    id: str
    client_secret: str
    amount: int
    currency: str = "usd"
    status: str

# Existing models from your current system
class AppointmentStatus(str, Enum):
    SCHEDULED = "scheduled"
    CONFIRMED = "confirmed"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"

class ServiceType(str, Enum):
    EYEBROW_MICROBLADING = "eyebrow_microblading"
    EYEBROW_POWDER_BROWS = "eyebrow_powder_brows"
    EYEBROW_TOUCH_UP = "eyebrow_touch_up"
    LIP_BLUSH = "lip_blush"
    LIP_NEUTRALIZATION = "lip_neutralization"
    EYELINER = "eyeliner"
    CONSULTATION = "consultation"
    REMOVAL = "removal"

class RecurrenceType(str, Enum):
    NONE = "none"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    TOUCH_UP = "touch_up"

class TransactionType(str, Enum):
    INCOME = "income"
    EXPENSE = "expense"

class ExpenseCategory(str, Enum):
    SUPPLIES = "supplies"
    RENT = "rent"
    MARKETING = "marketing"
    EQUIPMENT = "equipment"
    TRAINING = "training"
    INSURANCE = "insurance"
    OTHER = "other"

class ProductCategory(str, Enum):
    PIGMENTS = "pigments"
    NEEDLES = "needles"
    MACHINES = "machines"
    ANESTHETICS = "anesthetics"
    AFTERCARE = "aftercare"
    DISPOSABLES = "disposables"
    EQUIPMENT = "equipment"
    OTHER = "other"

class StockMovementType(str, Enum):
    IN = "in"
    OUT = "out"
    ADJUSTMENT = "adjustment"

class ClientCreate(BaseModel):
    first_name: str
    last_name: str
    email: str
    phone: str
    date_of_birth: Optional[str] = None
    skin_tone: Optional[str] = None
    hair_color: Optional[str] = None
    eye_color: Optional[str] = None
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    notes: Optional[str] = None

class ClientUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    skin_tone: Optional[str] = None
    hair_color: Optional[str] = None
    eye_color: Optional[str] = None
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    notes: Optional[str] = None

class Client(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Associate client with user
    first_name: str
    last_name: str
    email: str
    phone: str
    date_of_birth: Optional[str] = None
    skin_tone: Optional[str] = None
    hair_color: Optional[str] = None
    eye_color: Optional[str] = None
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    notes: Optional[str] = None
    photos: List[dict] = []
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class AppointmentCreate(BaseModel):
    client_id: str
    service_type: ServiceType
    appointment_date: datetime
    duration_minutes: int = 120
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: RecurrenceType = RecurrenceType.NONE
    send_reminders: bool = True

class AppointmentUpdate(BaseModel):
    client_id: Optional[str] = None
    service_type: Optional[ServiceType] = None
    appointment_date: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    status: Optional[AppointmentStatus] = None
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: Optional[RecurrenceType] = None
    send_reminders: Optional[bool] = None

class Appointment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Associate appointment with user
    client_id: str
    service_type: ServiceType
    appointment_date: datetime
    duration_minutes: int = 120
    status: AppointmentStatus = AppointmentStatus.SCHEDULED
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: RecurrenceType = RecurrenceType.NONE
    parent_appointment_id: Optional[str] = None
    send_reminders: bool = True
    reminder_sent: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class AppointmentWithClient(BaseModel):
    id: str
    user_id: str
    client_id: str
    client_name: str
    client_email: str
    client_phone: str
    service_type: ServiceType
    appointment_date: datetime
    duration_minutes: int
    status: AppointmentStatus
    notes: Optional[str] = None
    price: Optional[float] = None
    deposit: Optional[float] = None
    recurrence_type: RecurrenceType
    send_reminders: bool
    reminder_sent: bool
    created_at: datetime
    updated_at: datetime

class TransactionCreate(BaseModel):
    type: TransactionType
    amount: float
    description: str
    category: str
    date: Optional[datetime] = None
    client_id: Optional[str] = None
    appointment_id: Optional[str] = None

class TransactionUpdate(BaseModel):
    type: Optional[TransactionType] = None
    amount: Optional[float] = None
    description: Optional[str] = None
    category: Optional[str] = None
    date: Optional[datetime] = None
    client_id: Optional[str] = None
    appointment_id: Optional[str] = None

class Transaction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Associate transaction with user
    type: TransactionType
    amount: float
    description: str
    category: str
    date: datetime = Field(default_factory=datetime.utcnow)
    client_id: Optional[str] = None
    client_name: Optional[str] = None
    appointment_id: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class ProductCreate(BaseModel):
    name: str
    category: ProductCategory
    brand: Optional[str] = None
    color: Optional[str] = None
    size: Optional[str] = None
    current_stock: int = 0
    min_stock_level: int = 10
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    sku: Optional[str] = None
    description: Optional[str] = None

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[ProductCategory] = None
    brand: Optional[str] = None
    color: Optional[str] = None
    size: Optional[str] = None
    current_stock: Optional[int] = None
    min_stock_level: Optional[int] = None
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    sku: Optional[str] = None
    description: Optional[str] = None

class Product(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Associate product with user
    name: str
    category: ProductCategory
    brand: Optional[str] = None
    color: Optional[str] = None
    size: Optional[str] = None
    current_stock: int = 0
    min_stock_level: int = 10
    cost_per_unit: Optional[float] = None
    supplier: Optional[str] = None
    sku: Optional[str] = None
    description: Optional[str] = None
    total_purchased: int = 0
    total_used: int = 0
    last_restocked: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class StockMovementCreate(BaseModel):
    product_id: str
    type: StockMovementType
    quantity: int
    cost_per_unit: Optional[float] = None
    notes: Optional[str] = None
    reference: Optional[str] = None

class StockMovement(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Associate movement with user
    product_id: str
    type: StockMovementType
    quantity: int
    cost_per_unit: Optional[float] = None
    notes: Optional[str] = None
    reference: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class PhotoAnalysis(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str  # Associate analysis with user
    client_id: str
    photo_base64: str
    analysis_type: str
    ai_analysis: dict
    created_at: datetime = Field(default_factory=datetime.utcnow)