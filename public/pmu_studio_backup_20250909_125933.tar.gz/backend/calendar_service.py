from typing import Dict, List, Optional, Any, Tuple
import json
import logging
from datetime import datetime, timedelta, time
from pathlib import Path
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
import pytz
from bson import ObjectId

load_dotenv()
logger = logging.getLogger(__name__)

class AdvancedCalendarService:
    def __init__(self, db):
        self.db = db
        
        # Configuración de horarios de trabajo
        self.default_business_hours = {
            "monday": {"enabled": True, "start": "09:00", "end": "18:00"},
            "tuesday": {"enabled": True, "start": "09:00", "end": "18:00"},
            "wednesday": {"enabled": True, "start": "09:00", "end": "18:00"},
            "thursday": {"enabled": True, "start": "09:00", "end": "18:00"},
            "friday": {"enabled": True, "start": "09:00", "end": "18:00"},
            "saturday": {"enabled": True, "start": "10:00", "end": "16:00"},
            "sunday": {"enabled": False, "start": "10:00", "end": "16:00"}
        }
        
        # Duración de servicios (en minutos)
        self.service_durations = {
            "microblading": 180,  # 3 horas
            "powder_brows": 150,  # 2.5 horas
            "hybrid": 180,        # 3 horas
            "touch_up": 120,      # 2 horas
            "consultation": 60,   # 1 hora
            "correction": 240,    # 4 horas
            "color_refresh": 90   # 1.5 horas
        }
        
        # Estados de citas
        self.appointment_statuses = {
            "pending": "Pendiente",
            "confirmed": "Confirmada", 
            "in_progress": "En Progreso",
            "completed": "Completada",
            "cancelled": "Cancelada",
            "no_show": "No Show",
            "rescheduled": "Reprogramada"
        }

    async def get_availability(self, user_id: str, date: datetime, duration_minutes: int = 180) -> Dict[str, Any]:
        """Obtener disponibilidad de horarios para una fecha específica"""
        try:
            # Obtener horarios de trabajo del usuario (o usar por defecto)
            business_hours = await self._get_business_hours(user_id, date)
            
            if not business_hours["enabled"]:
                return {
                    "success": True,
                    "date": date.strftime("%Y-%m-%d"),
                    "available_slots": [],
                    "message": "No hay horarios de trabajo configurados para este día"
                }
            
            # Obtener citas existentes para esa fecha
            existing_appointments = await self._get_existing_appointments(user_id, date)
            
            # Obtener bloques de tiempo no disponibles
            blocked_times = await self._get_blocked_times(user_id, date)
            
            # Generar slots disponibles
            available_slots = self._generate_available_slots(
                business_hours, 
                existing_appointments, 
                blocked_times, 
                duration_minutes,
                date
            )
            
            return {
                "success": True,
                "date": date.strftime("%Y-%m-%d"),
                "available_slots": available_slots,
                "total_slots": len(available_slots),
                "business_hours": business_hours,
                "duration_minutes": duration_minutes
            }
            
        except Exception as e:
            logger.error(f"Error getting availability: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def book_appointment(self, user_id: str, booking_data: Dict[str, Any]) -> Dict[str, Any]:
        """Reservar una cita con validaciones avanzadas"""
        try:
            # Validar datos requeridos
            required_fields = ["client_id", "appointment_date", "service_type", "duration_minutes"]
            for field in required_fields:
                if field not in booking_data:
                    raise ValueError(f"Campo requerido faltante: {field}")
            
            appointment_datetime = datetime.fromisoformat(booking_data["appointment_date"].replace('Z', '+00:00'))
            duration_minutes = booking_data["duration_minutes"]
            
            # Verificar disponibilidad en tiempo real
            availability_check = await self._check_slot_availability(
                user_id, 
                appointment_datetime, 
                duration_minutes
            )
            
            if not availability_check["available"]:
                return {
                    "success": False,
                    "error": "El horario solicitado ya no está disponible",
                    "reason": availability_check["reason"]
                }
            
            # Calcular tiempo de finalización
            end_time = appointment_datetime + timedelta(minutes=duration_minutes)
            
            # Crear documento de cita
            appointment_doc = {
                "user_id": user_id,
                "client_id": booking_data["client_id"],
                "appointment_date": appointment_datetime,
                "end_time": end_time,
                "service_type": booking_data["service_type"],
                "duration_minutes": duration_minutes,
                "status": "confirmed",
                "price": booking_data.get("price", 0),
                "notes": booking_data.get("notes", ""),
                "booking_source": booking_data.get("booking_source", "app"),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "reminders_sent": [],
                "metadata": {
                    "booked_by": user_id,
                    "booking_ip": booking_data.get("booking_ip", ""),
                    "automatic_reminders": True
                }
            }
            
            # Insertar cita en la base de datos
            result = await self.db.appointments.insert_one(appointment_doc)
            appointment_id = str(result.inserted_id)
            
            # Programar recordatorios automáticos
            await self._schedule_automatic_reminders(appointment_id, appointment_datetime, booking_data["client_id"])
            
            # Obtener datos del cliente para la respuesta
            client_data = await self.db.clients.find_one({"_id": ObjectId(booking_data["client_id"])})
            
            return {
                "success": True,
                "appointment_id": appointment_id,
                "appointment_date": appointment_datetime.isoformat(),
                "end_time": end_time.isoformat(),
                "client_name": f"{client_data.get('first_name', '')} {client_data.get('last_name', '')}" if client_data else "Cliente",
                "service_type": booking_data["service_type"],
                "status": "confirmed",
                "message": "Cita reservada exitosamente"
            }
            
        except ValueError as ve:
            return {
                "success": False,
                "error": str(ve)
            }
        except Exception as e:
            logger.error(f"Error booking appointment: {str(e)}")
            return {
                "success": False,
                "error": "Error interno al reservar la cita"
            }

    async def reschedule_appointment(self, user_id: str, appointment_id: str, new_datetime: datetime, reason: str = "") -> Dict[str, Any]:
        """Reprogramar una cita existente"""
        try:
            # Verificar que la cita existe y pertenece al usuario
            appointment = await self.db.appointments.find_one({
                "_id": ObjectId(appointment_id),
                "user_id": user_id
            })
            
            if not appointment:
                return {
                    "success": False,
                    "error": "Cita no encontrada"
                }
            
            # Verificar disponibilidad en el nuevo horario
            availability_check = await self._check_slot_availability(
                user_id, 
                new_datetime, 
                appointment["duration_minutes"],
                exclude_appointment_id=appointment_id
            )
            
            if not availability_check["available"]:
                return {
                    "success": False,
                    "error": "El nuevo horario no está disponible",
                    "reason": availability_check["reason"]
                }
            
            # Calcular nuevo tiempo de finalización
            new_end_time = new_datetime + timedelta(minutes=appointment["duration_minutes"])
            
            # Actualizar la cita
            update_data = {
                "appointment_date": new_datetime,
                "end_time": new_end_time,
                "status": "confirmed",
                "updated_at": datetime.utcnow(),
                "reschedule_history": appointment.get("reschedule_history", []) + [{
                    "previous_date": appointment["appointment_date"],
                    "new_date": new_datetime,
                    "reason": reason,
                    "rescheduled_by": user_id,
                    "rescheduled_at": datetime.utcnow()
                }]
            }
            
            await self.db.appointments.update_one(
                {"_id": ObjectId(appointment_id)},
                {"$set": update_data}
            )
            
            # Reprogramar recordatorios
            await self._schedule_automatic_reminders(appointment_id, new_datetime, appointment["client_id"])
            
            return {
                "success": True,
                "appointment_id": appointment_id,
                "previous_date": appointment["appointment_date"].isoformat(),
                "new_date": new_datetime.isoformat(),
                "message": "Cita reprogramada exitosamente"
            }
            
        except Exception as e:
            logger.error(f"Error rescheduling appointment: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def get_calendar_view(self, user_id: str, start_date: datetime, end_date: datetime, view_type: str = "month") -> Dict[str, Any]:
        """Obtener vista de calendario con citas y disponibilidad"""
        try:
            # Obtener todas las citas en el rango
            appointments = await self.db.appointments.find({
                "user_id": user_id,
                "appointment_date": {
                    "$gte": start_date,
                    "$lte": end_date
                }
            }).to_list(1000)
            
            # Obtener datos de clientes
            client_ids = [ObjectId(apt["client_id"]) for apt in appointments if apt.get("client_id")]
            clients = {}
            if client_ids:
                client_docs = await self.db.clients.find({"_id": {"$in": client_ids}}).to_list(1000)
                clients = {str(client["_id"]): client for client in client_docs}
            
            # Formatear citas para el calendario
            calendar_events = []
            for apt in appointments:
                client = clients.get(apt["client_id"], {})
                client_name = f"{client.get('first_name', '')} {client.get('last_name', '')}".strip() or "Cliente"
                
                calendar_events.append({
                    "id": str(apt["_id"]),
                    "title": f"{client_name} - {apt['service_type']}",
                    "client_name": client_name,
                    "client_id": apt["client_id"],
                    "start": apt["appointment_date"].isoformat(),
                    "end": apt.get("end_time", apt["appointment_date"] + timedelta(minutes=apt.get("duration_minutes", 180))).isoformat(),
                    "service_type": apt["service_type"],
                    "status": apt.get("status", "confirmed"),
                    "price": apt.get("price", 0),
                    "notes": apt.get("notes", ""),
                    "duration_minutes": apt.get("duration_minutes", 180),
                    "color": self._get_status_color(apt.get("status", "confirmed"))
                })
            
            # Calcular estadísticas del período
            stats = await self._calculate_period_stats(user_id, start_date, end_date, appointments)
            
            return {
                "success": True,
                "view_type": view_type,
                "period": {
                    "start_date": start_date.strftime("%Y-%m-%d"),
                    "end_date": end_date.strftime("%Y-%m-%d"),
                    "days": (end_date - start_date).days + 1
                },
                "events": calendar_events,
                "stats": stats,
                "total_events": len(calendar_events)
            }
            
        except Exception as e:
            logger.error(f"Error getting calendar view: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def detect_conflicts(self, user_id: str, appointment_datetime: datetime, duration_minutes: int, exclude_id: str = None) -> Dict[str, Any]:
        """Detectar conflictos de horarios"""
        try:
            end_time = appointment_datetime + timedelta(minutes=duration_minutes)
            
            # Buscar citas que se superponen
            conflict_query = {
                "user_id": user_id,
                "status": {"$nin": ["cancelled", "no_show"]},
                "$or": [
                    # Cita nueva empieza durante una cita existente
                    {
                        "appointment_date": {"$lte": appointment_datetime},
                        "end_time": {"$gt": appointment_datetime}
                    },
                    # Cita nueva termina durante una cita existente
                    {
                        "appointment_date": {"$lt": end_time},
                        "end_time": {"$gte": end_time}
                    },
                    # Cita nueva contiene completamente una cita existente
                    {
                        "appointment_date": {"$gte": appointment_datetime},
                        "end_time": {"$lte": end_time}
                    }
                ]
            }
            
            if exclude_id:
                conflict_query["_id"] = {"$ne": ObjectId(exclude_id)}
            
            conflicts = await self.db.appointments.find(conflict_query).to_list(10)
            
            conflict_details = []
            for conflict in conflicts:
                # Obtener datos del cliente
                client = await self.db.clients.find_one({"_id": ObjectId(conflict["client_id"])})
                client_name = f"{client.get('first_name', '')} {client.get('last_name', '')}".strip() if client else "Cliente"
                
                conflict_details.append({
                    "appointment_id": str(conflict["_id"]),
                    "client_name": client_name,
                    "service_type": conflict["service_type"],
                    "start_time": conflict["appointment_date"].isoformat(),
                    "end_time": conflict.get("end_time", conflict["appointment_date"] + timedelta(minutes=conflict.get("duration_minutes", 180))).isoformat(),
                    "status": conflict.get("status", "confirmed")
                })
            
            return {
                "success": True,
                "has_conflicts": len(conflicts) > 0,
                "conflict_count": len(conflicts),
                "conflicts": conflict_details,
                "requested_slot": {
                    "start": appointment_datetime.isoformat(),
                    "end": end_time.isoformat(),
                    "duration_minutes": duration_minutes
                }
            }
            
        except Exception as e:
            logger.error(f"Error detecting conflicts: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    async def _get_business_hours(self, user_id: str, date: datetime) -> Dict[str, Any]:
        """Obtener horarios de trabajo para un día específico"""
        try:
            weekday = date.strftime("%A").lower()
            
            # Buscar configuración personalizada del usuario
            config = await self.db.business_config.find_one({"user_id": user_id})
            
            if config and "business_hours" in config:
                return config["business_hours"].get(weekday, self.default_business_hours[weekday])
            
            return self.default_business_hours[weekday]
            
        except Exception as e:
            logger.error(f"Error getting business hours: {str(e)}")
            return self.default_business_hours["monday"]  # Fallback

    async def _get_existing_appointments(self, user_id: str, date: datetime) -> List[Dict[str, Any]]:
        """Obtener citas existentes para una fecha"""
        try:
            start_of_day = date.replace(hour=0, minute=0, second=0, microsecond=0)
            end_of_day = start_of_day + timedelta(days=1)
            
            appointments = await self.db.appointments.find({
                "user_id": user_id,
                "appointment_date": {
                    "$gte": start_of_day,
                    "$lt": end_of_day
                },
                "status": {"$nin": ["cancelled", "no_show"]}
            }).to_list(50)
            
            return appointments
            
        except Exception as e:
            logger.error(f"Error getting existing appointments: {str(e)}")
            return []

    async def _get_blocked_times(self, user_id: str, date: datetime) -> List[Dict[str, Any]]:
        """Obtener bloques de tiempo no disponibles"""
        try:
            start_of_day = date.replace(hour=0, minute=0, second=0, microsecond=0)
            end_of_day = start_of_day + timedelta(days=1)
            
            blocked_times = await self.db.blocked_times.find({
                "user_id": user_id,
                "date": {
                    "$gte": start_of_day,
                    "$lt": end_of_day
                }
            }).to_list(20)
            
            return blocked_times
            
        except Exception as e:
            logger.error(f"Error getting blocked times: {str(e)}")
            return []

    def _generate_available_slots(self, business_hours: Dict, existing_appointments: List, blocked_times: List, duration_minutes: int, date: datetime) -> List[Dict[str, Any]]:
        """Generar slots de tiempo disponibles"""
        try:
            if not business_hours["enabled"]:
                return []
                
            # Parsear horarios de trabajo
            start_time = datetime.strptime(business_hours["start"], "%H:%M").time()
            end_time = datetime.strptime(business_hours["end"], "%H:%M").time()
            
            # Crear datetime completos para el día
            start_datetime = datetime.combine(date.date(), start_time)
            end_datetime = datetime.combine(date.date(), end_time)
            
            # Generar slots cada 30 minutos
            slots = []
            current_time = start_datetime
            slot_interval = timedelta(minutes=30)
            required_duration = timedelta(minutes=duration_minutes)
            
            while current_time + required_duration <= end_datetime:
                slot_end = current_time + required_duration
                
                # Verificar si el slot está libre
                is_available = True
                
                # Verificar contra citas existentes
                for apt in existing_appointments:
                    apt_start = apt["appointment_date"]
                    apt_end = apt.get("end_time", apt_start + timedelta(minutes=apt.get("duration_minutes", 180)))
                    
                    # Verificar superposición
                    if (current_time < apt_end and slot_end > apt_start):
                        is_available = False
                        break
                
                # Verificar contra bloques de tiempo
                if is_available:
                    for blocked in blocked_times:
                        blocked_start = blocked["start_time"]
                        blocked_end = blocked["end_time"]
                        
                        if (current_time < blocked_end and slot_end > blocked_start):
                            is_available = False
                            break
                
                if is_available:
                    slots.append({
                        "start_time": current_time.strftime("%H:%M"),
                        "end_time": slot_end.strftime("%H:%M"),
                        "start_datetime": current_time.isoformat(),
                        "end_datetime": slot_end.isoformat(),
                        "duration_minutes": duration_minutes,
                        "available": True
                    })
                
                current_time += slot_interval
            
            return slots
            
        except Exception as e:
            logger.error(f"Error generating available slots: {str(e)}")
            return []

    async def _check_slot_availability(self, user_id: str, appointment_datetime: datetime, duration_minutes: int, exclude_appointment_id: str = None) -> Dict[str, Any]:
        """Verificar disponibilidad de un slot específico en tiempo real"""
        try:
            # Detectar conflictos
            conflicts = await self.detect_conflicts(user_id, appointment_datetime, duration_minutes, exclude_appointment_id)
            
            if conflicts["has_conflicts"]:
                return {
                    "available": False,
                    "reason": "Conflicto con cita existente",
                    "conflicts": conflicts["conflicts"]
                }
            
            # Verificar horarios de trabajo
            business_hours = await self._get_business_hours(user_id, appointment_datetime)
            
            if not business_hours["enabled"]:
                return {
                    "available": False,
                    "reason": "Día no laborable"
                }
            
            # Verificar que esté dentro del horario de trabajo
            start_time = datetime.strptime(business_hours["start"], "%H:%M").time()
            end_time = datetime.strptime(business_hours["end"], "%H:%M").time()
            
            appointment_time = appointment_datetime.time()
            end_appointment_time = (appointment_datetime + timedelta(minutes=duration_minutes)).time()
            
            if appointment_time < start_time or end_appointment_time > end_time:
                return {
                    "available": False,
                    "reason": f"Horario fuera del horario de trabajo ({business_hours['start']}-{business_hours['end']})"
                }
            
            return {
                "available": True,
                "reason": "Slot disponible"
            }
            
        except Exception as e:
            logger.error(f"Error checking slot availability: {str(e)}")
            return {
                "available": False,
                "reason": f"Error verificando disponibilidad: {str(e)}"
            }

    async def _schedule_automatic_reminders(self, appointment_id: str, appointment_datetime: datetime, client_id: str):
        """Programar recordatorios automáticos"""
        try:
            # Crear recordatorios para 24 horas y 2 horas antes
            reminder_times = [
                {"hours_before": 24, "type": "24h_reminder"},
                {"hours_before": 2, "type": "2h_reminder"}
            ]
            
            for reminder in reminder_times:
                reminder_datetime = appointment_datetime - timedelta(hours=reminder["hours_before"])
                
                # Solo programar si el recordatorio es en el futuro
                if reminder_datetime > datetime.utcnow():
                    reminder_doc = {
                        "appointment_id": appointment_id,
                        "client_id": client_id,
                        "reminder_type": reminder["type"],
                        "scheduled_for": reminder_datetime,
                        "status": "pending",
                        "created_at": datetime.utcnow()
                    }
                    
                    await self.db.scheduled_reminders.insert_one(reminder_doc)
            
        except Exception as e:
            logger.error(f"Error scheduling reminders: {str(e)}")

    async def _calculate_period_stats(self, user_id: str, start_date: datetime, end_date: datetime, appointments: List) -> Dict[str, Any]:
        """Calcular estadísticas del período"""
        try:
            total_appointments = len(appointments)
            completed_appointments = len([apt for apt in appointments if apt.get("status") == "completed"])
            cancelled_appointments = len([apt for apt in appointments if apt.get("status") in ["cancelled", "no_show"]])
            
            # Calcular ingresos
            total_revenue = sum(apt.get("price", 0) for apt in appointments if apt.get("status") == "completed")
            
            # Servicios más populares
            service_counts = {}
            for apt in appointments:
                service = apt.get("service_type", "Desconocido")
                service_counts[service] = service_counts.get(service, 0) + 1
            
            popular_services = sorted(service_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            
            return {
                "total_appointments": total_appointments,
                "completed_appointments": completed_appointments,
                "cancelled_appointments": cancelled_appointments,
                "completion_rate": (completed_appointments / max(total_appointments, 1)) * 100,
                "cancellation_rate": (cancelled_appointments / max(total_appointments, 1)) * 100,
                "total_revenue": total_revenue,
                "average_revenue_per_appointment": total_revenue / max(completed_appointments, 1),
                "popular_services": [{"service": service, "count": count} for service, count in popular_services]
            }
            
        except Exception as e:
            logger.error(f"Error calculating period stats: {str(e)}")
            return {}

    def _get_status_color(self, status: str) -> str:
        """Obtener color para el estado de la cita"""
        color_map = {
            "pending": "#FFA500",      # Naranja
            "confirmed": "#32CD32",    # Verde lima
            "in_progress": "#1E90FF",  # Azul dodger
            "completed": "#228B22",    # Verde bosque
            "cancelled": "#DC143C",    # Rojo carmesí
            "no_show": "#8B0000",      # Rojo oscuro
            "rescheduled": "#9370DB"   # Violeta medio
        }
        return color_map.get(status, "#808080")  # Gris por defecto

# Esta función se inicializará cuando se importe el módulo
def create_calendar_service(db):
    return AdvancedCalendarService(db)