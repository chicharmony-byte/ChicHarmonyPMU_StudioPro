from typing import Dict, List, Optional, Any
import json
import logging
from datetime import datetime, date
from pathlib import Path
import os
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class DigitalFormsService:
    def __init__(self):
        self.base_path = Path(__file__).parent
        self.templates_path = self.base_path / "form_templates"
        self.templates_path.mkdir(exist_ok=True)
        
        # Idiomas soportados
        self.supported_languages = {
            "es": "Español",
            "en": "English", 
            "pt": "Português",
            "fr": "Français"
        }
        
        # Tipos de formularios disponibles
        self.form_types = {
            "consent": "Formulario de Consentimiento",
            "medical_history": "Historia Médica",
            "post_treatment": "Instrucciones Post-Tratamiento",
            "release": "Formulario de Liberación",
            "touch_up": "Formulario Touch-Up"
        }
        
        # Inicializar plantillas por defecto
        self._create_default_templates()

    def _create_default_templates(self):
        """Crear plantillas por defecto si no existen"""
        default_templates = {
            "consent": {
                "es": self._get_consent_template_es(),
                "en": self._get_consent_template_en(),
                "pt": self._get_consent_template_pt(),
                "fr": self._get_consent_template_fr()
            },
            "medical_history": {
                "es": self._get_medical_history_template_es(),
                "en": self._get_medical_history_template_en()
            },
            "post_treatment": {
                "es": self._get_post_treatment_template_es(),
                "en": self._get_post_treatment_template_en()
            }
        }
        
        for form_type, languages in default_templates.items():
            for lang, template in languages.items():
                template_file = self.templates_path / f"{form_type}_{lang}.json"
                if not template_file.exists():
                    with open(template_file, 'w', encoding='utf-8') as f:
                        json.dump(template, f, ensure_ascii=False, indent=2)

    def get_available_forms(self) -> Dict[str, Any]:
        """Obtener lista de formularios disponibles"""
        return {
            "form_types": self.form_types,
            "supported_languages": self.supported_languages,
            "total_templates": len(list(self.templates_path.glob("*.json")))
        }

    def get_form_template(self, form_type: str, language: str = "es") -> Dict[str, Any]:
        """Obtener plantilla de formulario"""
        try:
            if form_type not in self.form_types:
                raise ValueError(f"Tipo de formulario no válido: {form_type}")
            
            if language not in self.supported_languages:
                language = "es"  # Default to Spanish
            
            template_file = self.templates_path / f"{form_type}_{language}.json"
            
            if template_file.exists():
                with open(template_file, 'r', encoding='utf-8') as f:
                    template = json.load(f)
                
                return {
                    "success": True,
                    "form_type": form_type,
                    "language": language,
                    "template": template,
                    "editable": True
                }
            else:
                raise FileNotFoundError(f"Plantilla no encontrada: {form_type}_{language}")
                
        except Exception as e:
            logger.error(f"Error getting form template: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "form_type": form_type,
                "language": language
            }

    def save_custom_template(self, form_type: str, language: str, template_data: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        """Guardar plantilla personalizada"""
        try:
            if form_type not in self.form_types:
                raise ValueError(f"Tipo de formulario no válido: {form_type}")
            
            if language not in self.supported_languages:
                raise ValueError(f"Idioma no soportado: {language}")
            
            # Validar estructura de plantilla
            if not self._validate_template_structure(template_data):
                raise ValueError("Estructura de plantilla inválida")
            
            # Agregar metadatos
            template_data["metadata"] = {
                "created_by": user_id,
                "created_at": datetime.utcnow().isoformat(),
                "modified_at": datetime.utcnow().isoformat(),
                "version": "1.0",
                "custom": True
            }
            
            # Guardar plantilla personalizada
            custom_file = self.templates_path / f"{form_type}_{language}_custom_{user_id}.json"
            with open(custom_file, 'w', encoding='utf-8') as f:
                json.dump(template_data, f, ensure_ascii=False, indent=2)
            
            return {
                "success": True,
                "message": "Plantilla personalizada guardada exitosamente",
                "template_id": f"{form_type}_{language}_custom_{user_id}",
                "form_type": form_type,
                "language": language
            }
            
        except Exception as e:
            logger.error(f"Error saving custom template: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    def generate_form_instance(self, form_type: str, language: str, client_data: Dict[str, Any], user_id: str = None) -> Dict[str, Any]:
        """Generar instancia de formulario con datos del cliente"""
        try:
            # Obtener plantilla (personalizada si existe)
            if user_id:
                custom_template = self._get_custom_template(form_type, language, user_id)
                if custom_template:
                    template = custom_template
                else:
                    template_result = self.get_form_template(form_type, language)
                    template = template_result.get("template", {})
            else:
                template_result = self.get_form_template(form_type, language)
                template = template_result.get("template", {})
            
            # Rellenar campos con datos del cliente
            filled_form = self._fill_form_with_client_data(template, client_data)
            
            # Generar ID único para esta instancia
            form_instance_id = f"{form_type}_{language}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
            
            return {
                "success": True,
                "form_instance_id": form_instance_id,
                "form_type": form_type,
                "language": language,
                "form_data": filled_form,
                "client_data": client_data,
                "created_at": datetime.utcnow().isoformat(),
                "status": "draft",
                "requires_signature": True
            }
            
        except Exception as e:
            logger.error(f"Error generating form instance: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }

    def _get_custom_template(self, form_type: str, language: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Obtener plantilla personalizada si existe"""
        try:
            custom_file = self.templates_path / f"{form_type}_{language}_custom_{user_id}.json"
            if custom_file.exists():
                with open(custom_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            logger.warning(f"Error loading custom template: {str(e)}")
        return None

    def _fill_form_with_client_data(self, template: Dict[str, Any], client_data: Dict[str, Any]) -> Dict[str, Any]:
        """Rellenar formulario con datos del cliente"""
        filled_form = template.copy()
        
        # Mapeo de campos comunes
        field_mapping = {
            "client_name": client_data.get("first_name", "") + " " + client_data.get("last_name", ""),
            "client_email": client_data.get("email", ""),
            "client_phone": client_data.get("phone", ""),
            "client_age": client_data.get("age", ""),
            "date": datetime.now().strftime("%d/%m/%Y"),
            "treatment_date": client_data.get("appointment_date", ""),
            "treatment_type": client_data.get("service_type", "Micropigmentación de cejas")
        }
        
        # Reemplazar placeholders en el contenido
        if "content" in filled_form:
            content = json.dumps(filled_form["content"])
            for placeholder, value in field_mapping.items():
                content = content.replace(f"{{{placeholder}}}", str(value))
            filled_form["content"] = json.loads(content)
        
        return filled_form

    def _validate_template_structure(self, template: Dict[str, Any]) -> bool:
        """Validar estructura básica de plantilla"""
        required_fields = ["title", "content", "signature_required"]
        return all(field in template for field in required_fields)

    # Plantillas por defecto en español
    def _get_consent_template_es(self) -> Dict[str, Any]:
        return {
            "title": "Formulario de Consentimiento - Micropigmentación",
            "description": "Consentimiento informado para tratamiento de micropigmentación",
            "signature_required": True,
            "content": {
                "header": {
                    "clinic_name": "Chic Harmony - PMU Studio",
                    "date": "{date}",
                    "client_info": {
                        "name": "{client_name}",
                        "email": "{client_email}",
                        "phone": "{client_phone}",
                        "age": "{client_age}"
                    }
                },
                "sections": [
                    {
                        "title": "INFORMACIÓN DEL TRATAMIENTO",
                        "content": [
                            "• Tratamiento: {treatment_type}",
                            "• Fecha programada: {treatment_date}",
                            "• Técnico: PMU Studio Certified",
                            "• Duración aproximada: 2-3 horas"
                        ]
                    },
                    {
                        "title": "DECLARACIÓN DE CONSENTIMIENTO",
                        "content": [
                            "Yo, {client_name}, declaro que:",
                            "1. He sido informado(a) sobre el procedimiento de micropigmentación",
                            "2. Comprendo los riesgos y beneficios del tratamiento",
                            "3. He proporcionado información médica completa y veraz",
                            "4. Entiendo que los resultados pueden variar",
                            "5. Acepto seguir las instrucciones post-tratamiento"
                        ]
                    },
                    {
                        "title": "CONDICIONES MÉDICAS",
                        "content": [
                            "Confirmo que NO tengo ninguna de las siguientes condiciones:",
                            "• Embarazo o lactancia",
                            "• Diabetes no controlada",
                            "• Enfermedades autoinmunes activas",
                            "• Tratamientos con isotretinoína en los últimos 6 meses",
                            "• Alergias conocidas a pigmentos o anestésicos",
                            "• Tendencia a queloides o cicatrización anormal"
                        ]
                    },
                    {
                        "title": "CUIDADOS POST-TRATAMIENTO",
                        "content": [
                            "Me comprometo a seguir estas instrucciones:",
                            "• Mantener el área seca las primeras 24 horas",
                            "• Aplicar pomada cicatrizante según indicaciones",
                            "• Evitar exposición solar directa por 2 semanas",
                            "• No tocar, rascar o frotar el área tratada",
                            "• Asistir a la cita de retoque programada"
                        ]
                    }
                ],
                "signature_section": {
                    "client_signature": "Firma del Cliente: ____________________",
                    "date_signed": "Fecha: ____________________",
                    "technician_signature": "Firma del Técnico: ____________________",
                    "witness": "Testigo: ____________________"
                },
                "footer": {
                    "clinic_info": "Chic Harmony - PMU Studio | Professional Micropigmentation",
                    "contact": "Para emergencias: support@chic-harmony.com",
                    "version": "Versión 2.0 - 2025"
                }
            }
        }

    # Plantillas en inglés
    def _get_consent_template_en(self) -> Dict[str, Any]:
        return {
            "title": "Consent Form - Micropigmentation",
            "description": "Informed consent for micropigmentation treatment",
            "signature_required": True,
            "content": {
                "header": {
                    "clinic_name": "Chic Harmony - PMU Studio",
                    "date": "{date}",
                    "client_info": {
                        "name": "{client_name}",
                        "email": "{client_email}",
                        "phone": "{client_phone}",
                        "age": "{client_age}"
                    }
                },
                "sections": [
                    {
                        "title": "TREATMENT INFORMATION",
                        "content": [
                            "• Treatment: {treatment_type}",
                            "• Scheduled date: {treatment_date}",
                            "• Technician: PMU Studio Certified",
                            "• Approximate duration: 2-3 hours"
                        ]
                    },
                    {
                        "title": "CONSENT STATEMENT",
                        "content": [
                            "I, {client_name}, declare that:",
                            "1. I have been informed about the micropigmentation procedure",
                            "2. I understand the risks and benefits of the treatment",
                            "3. I have provided complete and truthful medical information",
                            "4. I understand that results may vary",
                            "5. I agree to follow post-treatment instructions"
                        ]
                    },
                    {
                        "title": "MEDICAL CONDITIONS",
                        "content": [
                            "I confirm that I DO NOT have any of the following conditions:",
                            "• Pregnancy or breastfeeding",
                            "• Uncontrolled diabetes",
                            "• Active autoimmune diseases",
                            "• Isotretinoin treatments in the last 6 months",
                            "• Known allergies to pigments or anesthetics",
                            "• Tendency to keloids or abnormal scarring"
                        ]
                    }
                ],
                "signature_section": {
                    "client_signature": "Client Signature: ____________________",
                    "date_signed": "Date: ____________________",
                    "technician_signature": "Technician Signature: ____________________",
                    "witness": "Witness: ____________________"
                }
            }
        }

    # Plantillas en portugués
    def _get_consent_template_pt(self) -> Dict[str, Any]:
        return {
            "title": "Formulário de Consentimento - Micropigmentação",
            "description": "Consentimento informado para tratamento de micropigmentação",
            "signature_required": True,
            "content": {
                "header": {
                    "clinic_name": "Chic Harmony - PMU Studio",
                    "date": "{date}",
                    "client_info": {
                        "name": "{client_name}",
                        "email": "{client_email}",
                        "phone": "{client_phone}",
                        "age": "{client_age}"
                    }
                },
                "sections": [
                    {
                        "title": "INFORMAÇÕES DO TRATAMENTO",
                        "content": [
                            "• Tratamento: {treatment_type}",
                            "• Data programada: {treatment_date}",
                            "• Técnico: PMU Studio Certificado",
                            "• Duração aproximada: 2-3 horas"
                        ]
                    },
                    {
                        "title": "DECLARAÇÃO DE CONSENTIMENTO",
                        "content": [
                            "Eu, {client_name}, declaro que:",
                            "1. Fui informado(a) sobre o procedimento de micropigmentação",
                            "2. Compreendo os riscos e benefícios do tratamento",
                            "3. Forneci informações médicas completas e verdadeiras",
                            "4. Entendo que os resultados podem variar",
                            "5. Aceito seguir as instruções pós-tratamento"
                        ]
                    }
                ]
            }
        }

    # Plantillas en francés
    def _get_consent_template_fr(self) -> Dict[str, Any]:
        return {
            "title": "Formulaire de Consentement - Micropigmentation",
            "description": "Consentement éclairé pour traitement de micropigmentation",
            "signature_required": True,
            "content": {
                "header": {
                    "clinic_name": "Chic Harmony - PMU Studio",
                    "date": "{date}",
                    "client_info": {
                        "name": "{client_name}",
                        "email": "{client_email}",
                        "phone": "{client_phone}",
                        "age": "{client_age}"
                    }
                },
                "sections": [
                    {
                        "title": "INFORMATIONS SUR LE TRAITEMENT",
                        "content": [
                            "• Traitement: {treatment_type}",
                            "• Date programmée: {treatment_date}",
                            "• Technicien: PMU Studio Certifié",
                            "• Durée approximative: 2-3 heures"
                        ]
                    }
                ]
            }
        }

    # Plantillas de historia médica
    def _get_medical_history_template_es(self) -> Dict[str, Any]:
        return {
            "title": "Historia Médica - PMU Studio",
            "description": "Cuestionario médico previo al tratamiento",
            "signature_required": True,
            "content": {
                "header": {
                    "title": "HISTORIA MÉDICA CONFIDENCIAL",
                    "client_name": "{client_name}",
                    "date": "{date}"
                },
                "sections": [
                    {
                        "title": "INFORMACIÓN GENERAL",
                        "fields": [
                            {"type": "text", "label": "Nombre completo", "value": "{client_name}"},
                            {"type": "number", "label": "Edad", "value": "{client_age}"},
                            {"type": "text", "label": "Ocupación", "value": ""},
                            {"type": "text", "label": "Teléfono de emergencia", "value": ""}
                        ]
                    },
                    {
                        "title": "CONDICIONES MÉDICAS",
                        "fields": [
                            {"type": "checkbox", "label": "¿Está embarazada o amamantando?", "value": False},
                            {"type": "checkbox", "label": "¿Tiene diabetes?", "value": False},
                            {"type": "checkbox", "label": "¿Toma medicamentos anticoagulantes?", "value": False},
                            {"type": "checkbox", "label": "¿Tiene alergias conocidas?", "value": False},
                            {"type": "text", "label": "Si tiene alergias, especifique:", "value": ""}
                        ]
                    }
                ]
            }
        }

    def _get_medical_history_template_en(self) -> Dict[str, Any]:
        return {
            "title": "Medical History - PMU Studio",
            "description": "Pre-treatment medical questionnaire",
            "signature_required": True,
            "content": {
                "header": {
                    "title": "CONFIDENTIAL MEDICAL HISTORY",
                    "client_name": "{client_name}",
                    "date": "{date}"
                },
                "sections": [
                    {
                        "title": "GENERAL INFORMATION",
                        "fields": [
                            {"type": "text", "label": "Full name", "value": "{client_name}"},
                            {"type": "number", "label": "Age", "value": "{client_age}"},
                            {"type": "text", "label": "Occupation", "value": ""},
                            {"type": "text", "label": "Emergency contact", "value": ""}
                        ]
                    }
                ]
            }
        }

    # Plantillas de post-tratamiento
    def _get_post_treatment_template_es(self) -> Dict[str, Any]:
        return {
            "title": "Instrucciones Post-Tratamiento",
            "description": "Cuidados posteriores al tratamiento de micropigmentación",
            "signature_required": False,
            "content": {
                "header": {
                    "title": "CUIDADOS POST-TRATAMIENTO",
                    "subtitle": "Sigue estas instrucciones para una sanación óptima",
                    "client_name": "{client_name}",
                    "treatment_date": "{treatment_date}"
                },
                "sections": [
                    {
                        "title": "PRIMERAS 24 HORAS",
                        "content": [
                            "• Mantén el área completamente seca",
                            "• Aplica pomada cicatrizante cada 2-3 horas",
                            "• Evita tocar o frotar la zona",
                            "• No uses maquillaje en el área tratada",
                            "• Duerme con la cabeza elevada"
                        ]
                    },
                    {
                        "title": "DÍAS 2-7",
                        "content": [
                            "• Lava suavemente con agua tibia y jabón neutro",
                            "• Seca con toques suaves, no frotes",
                            "• Continúa aplicando pomada cicatrizante",
                            "• Es normal que se formen pequeñas costras",
                            "• NO arranques las costras, deben caer naturalmente"
                        ]
                    },
                    {
                        "title": "SEMANAS 2-4",
                        "content": [
                            "• Evita exposición solar directa",
                            "• Usa protector solar FPS 30+ cuando salgas",
                            "• Evita saunas, piscinas y jacuzzis",
                            "• No uses productos exfoliantes en el área",
                            "• El color se verá más claro, es normal"
                        ]
                    },
                    {
                        "title": "SEÑALES DE ALERTA - CONTACTA INMEDIATAMENTE",
                        "content": [
                            "• Enrojecimiento excesivo después de 48 horas",
                            "• Secreción con mal olor",
                            "• Hinchazón que aumenta en lugar de disminuir",
                            "• Fiebre o malestar general",
                            "• Dolor intenso que no mejora"
                        ]
                    }
                ],
                "footer": {
                    "contact": "EMERGENCIAS: support@chic-harmony.com",
                    "touch_up": "Touch-up programado: 6 semanas después del tratamiento"
                }
            }
        }

    def _get_post_treatment_template_en(self) -> Dict[str, Any]:
        return {
            "title": "Post-Treatment Instructions",
            "description": "Aftercare for micropigmentation treatment",
            "signature_required": False,
            "content": {
                "header": {
                    "title": "POST-TREATMENT CARE",
                    "subtitle": "Follow these instructions for optimal healing",
                    "client_name": "{client_name}",
                    "treatment_date": "{treatment_date}"
                },
                "sections": [
                    {
                        "title": "FIRST 24 HOURS",
                        "content": [
                            "• Keep the area completely dry",
                            "• Apply healing ointment every 2-3 hours",
                            "• Avoid touching or rubbing the area",
                            "• Do not use makeup on treated area",
                            "• Sleep with head elevated"
                        ]
                    }
                ]
            }
        }

# Instancia global del servicio
forms_service = DigitalFormsService()