from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content
import os
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import logging
from dotenv import load_dotenv

load_dotenv()

# Email configuration
SENDGRID_API_KEY = os.environ.get("SENDGRID_API_KEY", "demo_key")
SENDER_EMAIL = os.environ.get("SENDER_EMAIL", "info@chic-harmony.com")
SENDER_NAME = "Chic Harmony - PMU Studio"

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        self.sg = SendGridAPIClient(api_key=SENDGRID_API_KEY) if SENDGRID_API_KEY != "demo_key" else None
        self.sender_email = SENDER_EMAIL
        self.sender_name = SENDER_NAME

    def send_email(self, to_email: str, subject: str, html_content: str, plain_content: str = None) -> bool:
        """Send email using SendGrid"""
        try:
            if not self.sg:
                logger.info(f"[DEMO MODE] Would send email to {to_email}: {subject}")
                return True

            from_email = Email(self.sender_email, self.sender_name)
            to_email_obj = To(to_email)
            
            mail = Mail(
                from_email=from_email,
                to_emails=to_email_obj,
                subject=subject,
                html_content=html_content,
                plain_text_content=plain_content or self._html_to_plain(html_content)
            )

            response = self.sg.send(mail)
            logger.info(f"Email sent successfully to {to_email}. Status: {response.status_code}")
            return response.status_code == 202

        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {str(e)}")
            return False

    def _html_to_plain(self, html_content: str) -> str:
        """Convert HTML to plain text (basic conversion)"""
        import re
        # Remove HTML tags
        plain = re.sub('<[^<]+?>', '', html_content)
        # Replace multiple whitespace with single space
        plain = re.sub(r'\s+', ' ', plain)
        return plain.strip()

    def send_welcome_email(self, user_email: str, username: str, plan: str) -> bool:
        """Send welcome email to new users"""
        
        plan_features = {
            "standard": [
                "✓ Gestión completa de clientes",
                "✓ Sistema de citas y calendario", 
                "✓ Notificaciones y recordatorios"
            ],
            "premium": [
                "✓ Todo lo de Standard",
                "✓ Dashboard financiero completo",
                "✓ Gestión de inventario avanzada",
                "✓ Reportes y análisis detallados"
            ],
            "executive": [
                "✓ Todo lo de Premium",
                "✓ Herramientas IA para análisis facial",
                "✓ Recomendador inteligente de pigmentos",
                "✓ Análisis de simetría automático",
                "✓ Soporte prioritario 24/7"
            ]
        }

        plan_prices = {
            "standard": "$35/mes",
            "premium": "$65/mes", 
            "executive": "$120/mes"
        }

        features_html = "<br>".join(plan_features.get(plan, plan_features["standard"]))
        plan_name = plan.title()
        plan_price = plan_prices.get(plan, "$35/mes")

        # Add conditional content based on plan
        executive_step = "<li><strong>Explora las herramientas IA</strong> para análisis facial avanzado</li>" if plan == "executive" else ""
        premium_step = "<li><strong>Configura tu dashboard financiero</strong> para tracking de ingresos</li>" if plan in ["premium", "executive"] else ""
        support_text = " o accede a soporte prioritario desde tu dashboard" if plan == "executive" else ""

        subject = f"¡Bienvenido a PMU Studio, {username}!"
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #E879F9 0%, #8B5CF6 100%); padding: 40px 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold; letter-spacing: 1px;">
                    🌸 PMU STUDIO
                </h1>
                <p style="color: white; margin: 8px 0 0 0; font-style: italic; opacity: 0.9;">
                    Professional Micropigmentation
                </p>
            </div>

            <!-- Content -->
            <div style="padding: 40px 30px; background: white;">
                <h2 style="color: #1f2937; margin-bottom: 20px;">¡Bienvenido, {username}! 🎉</h2>
                
                <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 25px;">
                    Gracias por suscribirte a <strong>PMU Studio</strong>. Tu cuenta <strong>{plan_name}</strong> 
                    está lista y puedes empezar a gestionar tu negocio de micropigmentación profesionalmente.
                </p>

                <!-- Plan Details -->
                <div style="background: #f3f4f6; border-radius: 8px; padding: 25px; margin-bottom: 30px;">
                    <h3 style="color: #E879F9; margin: 0 0 15px 0; display: flex; align-items: center;">
                        👑 Plan {plan_name} - {plan_price}
                    </h3>
                    <div style="color: #4b5563; line-height: 1.8;">
                        {features_html}
                    </div>
                </div>

                <!-- Quick Start Guide -->
                <div style="margin-bottom: 30px;">
                    <h3 style="color: #1f2937; margin-bottom: 15px;">🚀 Primeros Pasos:</h3>
                    <ol style="color: #4b5563; line-height: 1.8; padding-left: 20px;">
                        <li><strong>Añade tus primeros clientes</strong> en la sección Client Management</li>
                        <li><strong>Configura tu calendario</strong> para gestionar citas eficientemente</li>
                        <li><strong>Personaliza las notificaciones</strong> automáticas</li>
                        {executive_step}
                        {premium_step}
                    </ol>
                </div>

                <!-- Support -->
                <div style="background: #ecfdf5; border-left: 4px solid #10b981; padding: 20px; margin-bottom: 25px;">
                    <h4 style="color: #065f46; margin: 0 0 10px 0;">💬 Soporte y Ayuda</h4>
                    <p style="color: #047857; margin: 0; font-size: 14px;">
                        ¿Necesitas ayuda? Estamos aquí para apoyarte. Contacta nuestro equipo de soporte 
                        en <strong>support@chic-harmony.com</strong>{support_text}.
                    </p>
                </div>

                <!-- CTA Button -->
                <div style="text-align: center; margin: 30px 0;">
                    <a href="https://chic-harmony-pmu.preview.emergentagent.com/login.html" 
                       style="background: #E879F9; color: white; padding: 15px 30px; text-decoration: none; 
                              border-radius: 8px; font-weight: bold; display: inline-block;">
                        🎯 Acceder a Mi Studio
                    </a>
                </div>
            </div>

            <!-- Footer -->
            <div style="background: #1f2937; padding: 30px; text-align: center;">
                <div style="color: #E879F9; font-weight: bold; margin-bottom: 10px;">
                    Chic Harmony
                </div>
                <div style="color: #9ca3af; font-size: 12px;">
                    © 2025 Chic Harmony – PMU Studio v1.0<br>
                    Professional Micropigmentation Management System
                </div>
            </div>
        </div>
        """

        return self.send_email(user_email, subject, html_content)

    def send_appointment_confirmation(self, client_email: str, client_name: str, 
                                    appointment_date: datetime, service_type: str, 
                                    price: float = None, notes: str = None) -> bool:
        """Send appointment confirmation email"""
        
        formatted_date = appointment_date.strftime("%A, %B %d, %Y")
        formatted_time = appointment_date.strftime("%I:%M %p")
        
        # Build conditional sections
        price_section = f'<div style="margin-bottom: 15px;"><strong style="color: #065f46;">💰 Precio:</strong> <span style="color: #047857;">${price}</span></div>' if price else ""
        notes_section = f'<div style="margin-bottom: 15px;"><strong style="color: #065f46;">📝 Notas:</strong> <span style="color: #047857;">{notes}</span></div>' if notes else ""
        
        subject = f"Confirmación de Cita - {service_type}"
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 24px;">✅ Cita Confirmada</h1>
                <p style="color: white; margin: 8px 0 0 0; opacity: 0.9;">PMU Studio - Chic Harmony</p>
            </div>

            <!-- Content -->
            <div style="padding: 30px; background: white;">
                <h2 style="color: #1f2937; margin-bottom: 20px;">¡Hola, {client_name}!</h2>
                
                <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 25px;">
                    Tu cita ha sido <strong>confirmada exitosamente</strong>. Aquí tienes todos los detalles:
                </p>

                <!-- Appointment Details -->
                <div style="background: #f0fdf4; border: 2px solid #10b981; border-radius: 12px; padding: 25px; margin-bottom: 30px;">
                    <h3 style="color: #065f46; margin: 0 0 20px 0; font-size: 18px;">📋 Detalles de tu Cita</h3>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #065f46;">Servicio:</strong> 
                        <span style="color: #047857;">{service_type}</span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #065f46;">📅 Fecha:</strong> 
                        <span style="color: #047857;">{formatted_date}</span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #065f46;">🕐 Hora:</strong> 
                        <span style="color: #047857;">{formatted_time}</span>
                    </div>
                    
                    {price_section}
                    {notes_section}
                </div>

                <!-- Pre-Appointment Instructions -->
                <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; margin-bottom: 25px;">
                    <h4 style="color: #92400e; margin: 0 0 15px 0;">⚠️ Instrucciones Pre-Tratamiento</h4>
                    <ul style="color: #b45309; margin: 0; padding-left: 20px; line-height: 1.6;">
                        <li>Evita el consumo de alcohol 24h antes de la cita</li>
                        <li>No uses medicamentos anticoagulantes</li>
                        <li>Evita tratamientos faciales 1 semana antes</li>
                        <li>Llega 10 minutos antes de tu cita</li>
                        <li>Trae una identificación válida</li>
                    </ul>
                </div>

                <!-- Reminders -->
                <div style="background: #dbeafe; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 25px;">
                    <h4 style="color: #1e40af; margin: 0 0 10px 0;">🔔 Recordatorios Automáticos</h4>
                    <p style="color: #1d4ed8; margin: 0; font-size: 14px;">
                        Te enviaremos recordatorios automáticos:<br>
                        • 7 días antes de tu cita<br>
                        • 24 horas antes de tu cita<br>
                        • Recordatorio de touch-up (30 días después)
                    </p>
                </div>

                <!-- Contact Info -->
                <div style="text-align: center; margin: 25px 0;">
                    <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px;">
                        ¿Necesitas reprogramar o tienes preguntas?
                    </p>
                    <a href="mailto:appointments@chic-harmony.com" 
                       style="background: #10b981; color: white; padding: 12px 25px; text-decoration: none; 
                              border-radius: 6px; font-weight: bold; display: inline-block;">
                        📧 Contactar PMU Studio
                    </a>
                </div>
            </div>

            <!-- Footer -->
            <div style="background: #1f2937; padding: 20px; text-align: center;">
                <div style="color: #E879F9; font-weight: bold; margin-bottom: 8px;">Chic Harmony - PMU Studio</div>
                <div style="color: #9ca3af; font-size: 12px;">
                    Professional Micropigmentation<br>
                    © 2025 Chic Harmony – Todos los derechos reservados
                </div>
            </div>
        </div>
        """

        return self.send_email(client_email, subject, html_content)

    def send_appointment_reminder(self, client_email: str, client_name: str, 
                                 appointment_date: datetime, service_type: str, 
                                 days_before: int) -> bool:
        """Send appointment reminder email"""
        
        if days_before == 1:
            subject = "🚨 Recordatorio: Tu cita es MAÑANA"
            time_text = "mañana"
            
            reminder_content = """
            <!-- 24h Reminder Specific -->
            <div style="background: #fee2e2; border-left: 4px solid #ef4444; padding: 20px; margin-bottom: 25px;">
                <h4 style="color: #dc2626; margin: 0 0 15px 0;">🚨 Recordatorios Importantes para Mañana</h4>
                <ul style="color: #dc2626; margin: 0; padding-left: 20px; line-height: 1.8;">
                    <li><strong>Desayuna ligero</strong> - evita comidas pesadas</li>
                    <li><strong>Hidratación</strong> - bebe suficiente agua</li>
                    <li><strong>Descansa bien</strong> - una buena noche de sueño</li>
                    <li><strong>Llega 10 minutos antes</strong> de tu hora programada</li>
                    <li><strong>Trae identificación</strong> válida</li>
                </ul>
            </div>
            """
        elif days_before == 7:
            subject = "📅 Recordatorio: Tu cita es la próxima semana"
            time_text = "en 7 días"
            
            reminder_content = """
            <!-- 7 Day Reminder Specific -->
            <div style="background: #e0f2fe; border-left: 4px solid #0284c7; padding: 20px; margin-bottom: 25px;">
                <h4 style="color: #0369a1; margin: 0 0 15px 0;">📝 Preparación para tu Cita</h4>
                <p style="color: #0284c7; margin: 0; line-height: 1.6;">
                    Tu cita se acerca. Recuerda seguir las instrucciones pre-tratamiento que te enviamos 
                    en la confirmación. Si tienes alguna pregunta, no dudes en contactarnos.
                </p>
            </div>
            """
        else:
            subject = f"📅 Recordatorio: Tu cita es en {days_before} días"
            time_text = f"en {days_before} días"
            
            reminder_content = """
            <!-- General Reminder -->
            <div style="background: #e0f2fe; border-left: 4px solid #0284c7; padding: 20px; margin-bottom: 25px;">
                <h4 style="color: #0369a1; margin: 0 0 15px 0;">📝 Preparación para tu Cita</h4>
                <p style="color: #0284c7; margin: 0; line-height: 1.6;">
                    Tu cita se acerca. Recuerda seguir las instrucciones pre-tratamiento que te enviamos 
                    en la confirmación. Si tienes alguna pregunta, no dudes en contactarnos.
                </p>
            </div>
            """

        formatted_date = appointment_date.strftime("%A, %B %d, %Y")
        formatted_time = appointment_date.strftime("%I:%M %p")
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 24px;">⏰ Recordatorio de Cita</h1>
                <p style="color: white; margin: 8px 0 0 0; opacity: 0.9;">PMU Studio - Chic Harmony</p>
            </div>

            <!-- Content -->
            <div style="padding: 30px; background: white;">
                <h2 style="color: #1f2937; margin-bottom: 20px;">¡Hola, {client_name}!</h2>
                
                <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 25px;">
                    Este es un recordatorio amigable de que tu cita está programada para <strong>{time_text}</strong>.
                </p>

                <!-- Appointment Details -->
                <div style="background: #fef3c7; border: 2px solid #f59e0b; border-radius: 12px; padding: 25px; margin-bottom: 30px;">
                    <h3 style="color: #92400e; margin: 0 0 20px 0; font-size: 18px;">📋 Detalles de tu Cita</h3>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #92400e;">Servicio:</strong> 
                        <span style="color: #b45309;">{service_type}</span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #92400e;">📅 Fecha:</strong> 
                        <span style="color: #b45309;">{formatted_date}</span>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #92400e;">🕐 Hora:</strong> 
                        <span style="color: #b45309;">{formatted_time}</span>
                    </div>
                </div>

                {reminder_content}

                <!-- Contact Info -->
                <div style="text-align: center; margin: 25px 0;">
                    <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px;">
                        ¿Necesitas reprogramar o tienes preguntas?
                    </p>
                    <a href="mailto:appointments@chic-harmony.com" 
                       style="background: #f59e0b; color: white; padding: 12px 25px; text-decoration: none; 
                              border-radius: 6px; font-weight: bold; display: inline-block;">
                        📞 Contactar PMU Studio
                    </a>
                </div>
            </div>

            <!-- Footer -->
            <div style="background: #1f2937; padding: 20px; text-align: center;">
                <div style="color: #E879F9; font-weight: bold; margin-bottom: 8px;">Chic Harmony - PMU Studio</div>
                <div style="color: #9ca3af; font-size: 12px;">
                    Professional Micropigmentation<br>
                    © 2025 Chic Harmony – Todos los derechos reservados
                </div>
            </div>
        </div>
        """

        return self.send_email(client_email, subject, html_content)

    def send_touchup_reminder(self, client_email: str, client_name: str, 
                             original_appointment_date: datetime, service_type: str) -> bool:
        """Send touch-up reminder email (30 days after original appointment)"""
        
        subject = "💫 Tiempo de Touch-Up - PMU Studio"
        formatted_date = original_appointment_date.strftime("%B %d, %Y")
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 24px;">💫 Touch-Up Reminder</h1>
                <p style="color: white; margin: 8px 0 0 0; opacity: 0.9;">PMU Studio - Chic Harmony</p>
            </div>

            <!-- Content -->
            <div style="padding: 30px; background: white;">
                <h2 style="color: #1f2937; margin-bottom: 20px;">¡Hola, {client_name}!</h2>
                
                <p style="color: #4b5563; font-size: 16px; line-height: 1.6; margin-bottom: 25px;">
                    Han pasado 30 días desde tu tratamiento de <strong>{service_type}</strong> el {formatted_date}. 
                    ¡Es el momento perfecto para tu sesión de touch-up!
                </p>

                <!-- Touch-Up Benefits -->
                <div style="background: linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%); 
                           border: 2px solid #8b5cf6; border-radius: 12px; padding: 25px; margin-bottom: 30px;">
                    <h3 style="color: #7c2d92; margin: 0 0 20px 0; font-size: 18px;">✨ ¿Por qué es importante el Touch-Up?</h3>
                    
                    <ul style="color: #7c2d92; margin: 0; padding-left: 20px; line-height: 1.8;">
                        <li><strong>Perfecciona el resultado</strong> - Ajustes finales de color y forma</li>
                        <li><strong>Prolonga la duración</strong> - Mantiene el color vibrante por más tiempo</li>
                        <li><strong>Rellena áreas</strong> - Corrige cualquier área que haya sanado más clara</li>
                        <li><strong>Optimiza simetría</strong> - Perfecciona cualquier pequeña asimetría</li>
                        <li><strong>Resultado final perfecto</strong> - Tu look definitivo y profesional</li>
                    </ul>
                </div>

                <!-- Timing Information -->
                <div style="background: #ecfdf5; border-left: 4px solid #10b981; padding: 20px; margin-bottom: 25px;">
                    <h4 style="color: #065f46; margin: 0 0 15px 0;">⏰ Momento Ideal para Touch-Up</h4>
                    <p style="color: #047857; margin: 0; line-height: 1.6;">
                        <strong>Entre 4-8 semanas</strong> después del tratamiento inicial es el momento perfecto. 
                        Tu piel ya ha sanado completamente y podemos evaluar con precisión qué ajustes necesita 
                        tu micropigmentación para lograr el resultado más hermoso y duradero.
                    </p>
                </div>

                <!-- Special Offer -->
                <div style="background: linear-gradient(135deg, #fef7cd 0%, #fef3c7 100%); 
                           border: 2px solid #f59e0b; border-radius: 12px; padding: 25px; margin-bottom: 30px; text-align: center;">
                    <h3 style="color: #92400e; margin: 0 0 15px 0;">🎁 Oferta Especial Touch-Up</h3>
                    <div style="font-size: 24px; color: #b45309; font-weight: bold; margin-bottom: 10px;">
                        20% OFF
                    </div>
                    <p style="color: #92400e; margin: 0; font-size: 14px;">
                        Oferta válida solo para clientes existentes durante las próximas 2 semanas
                    </p>
                </div>

                <!-- CTA Buttons -->
                <div style="text-align: center; margin: 30px 0;">
                    <a href="https://chic-harmony-pmu.preview.emergentagent.com/login.html" 
                       style="background: #8b5cf6; color: white; padding: 15px 30px; text-decoration: none; 
                              border-radius: 8px; font-weight: bold; display: inline-block; margin: 0 10px 10px 0;">
                        📅 Agendar Touch-Up
                    </a>
                    <a href="mailto:appointments@chic-harmony.com" 
                       style="background: #6b7280; color: white; padding: 15px 30px; text-decoration: none; 
                              border-radius: 8px; font-weight: bold; display: inline-block;">
                        💬 Consultar Dudas
                    </a>
                </div>

                <!-- Care Instructions -->
                <div style="background: #f1f5f9; border-left: 4px solid #64748b; padding: 20px;">
                    <h4 style="color: #334155; margin: 0 0 15px 0;">💡 Mientras Tanto</h4>
                    <p style="color: #475569; margin: 0; font-size: 14px; line-height: 1.6;">
                        Continúa cuidando tu micropigmentación con protector solar, evita exfoliantes agresivos 
                        en la zona y mantén la piel hidratada. Si notas cualquier cambio o tienes preguntas, 
                        no dudes en contactarnos.
                    </p>
                </div>
            </div>

            <!-- Footer -->
            <div style="background: #1f2937; padding: 20px; text-align: center;">
                <div style="color: #E879F9; font-weight: bold; margin-bottom: 8px;">Chic Harmony - PMU Studio</div>
                <div style="color: #9ca3af; font-size: 12px;">
                    Professional Micropigmentation<br>
                    © 2025 Chic Harmony – Especialistas en Micropigmentación
                </div>
            </div>
        </div>
        """

        return self.send_email(client_email, subject, html_content)

# Create global instance
email_service = EmailService()